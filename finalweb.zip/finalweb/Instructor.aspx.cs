﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using BusinessLogic;
using System.Data;

public partial class Instructor : System.Web.UI.Page
{
    InstructorBAL InstructBA = new InstructorBAL();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            displayStudentList();
        }
    }

    public void searchUser(String userType)
    {


        GridView2.DataSource = InstructBA.getSpecificAccount(userType, stuID.Text.ToString());
        GridView2.DataBind();
        lblFail.Text = "";
    }

    public void displayStudentList()
    {


        GridView1.DataSource = InstructBA.getAllAccounts();
        GridView1.DataBind();
        
    }

    protected void SearchStudent(object sender, EventArgs e)
    {
        int number;

        if ((ddlSearch.SelectedValue == "Student") && (int.TryParse(stuID.Text, out number)))
        {
            searchUser("Student");

        }
        else if (ddlSearch.SelectedValue == "Faculty")
        {
            searchUser("Faculty");
        }
        else if (ddlSearch.SelectedValue == "CompanyContact")
        {
            searchUser("CompanyContact");
        }
        else
        {
            lblFail.Text = "Please enter a correct Student ID or Instructor Email Address.";
            

        }



    }

}