﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using BusinessLogic;
using System.Data;

public partial class InstructorInteractions : System.Web.UI.Page
{

    InstructorBAL instructBAL = new InstructorBAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
    }

    public void searchApplications(String userType)
    {
        



        GridView2.DataSource = instructBAL.getApplications(userType, txtSearch.Text.ToString());
        GridView2.DataBind();
        lblFail.Text = "";

    }


    protected void SearchStudent(object sender, EventArgs e)
    {
        int number;

        if ((ddlSearch.SelectedValue == "Student") && (int.TryParse(txtSearch.Text, out number)))
        {
            searchApplications("Student");
        }
        else if (ddlSearch.SelectedValue == "CompanyContact")
        {
            searchApplications("CompanyContact");
        }
        else { lblFail.Text = "Please enter the correct information."; }
    }
}
