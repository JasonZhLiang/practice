﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class DisplayStudentPracticumFiles : System.Web.UI.Page
{
    InstructorBAL instructBAL = new InstructorBAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                fillDataGrid();
            }
        }
    }



    public void fillDataGrid()
    {


        GridView1.DataSource = instructBAL.getStudentFiles();
        GridView1.DataBind();

        GridView2.DataSource = instructBAL.getCompanyContactEvaluations();
        GridView2.DataBind();
    }
    protected void FillGridView_RowCommand(Object sender, GridViewCommandEventArgs e)
    {

       
        if (e.CommandName == "Print")
        {
           
            int index = Convert.ToInt32(e.CommandArgument);

           
            GridViewRow selectedRow = GridView1.Rows[index];

            String id = selectedRow.Cells[0].Text;
            int anID = Convert.ToInt32(id);
            Display(anID);

        }

        else if (e.CommandName == "PrintEval")
        {
            
            int index = Convert.ToInt32(e.CommandArgument);

            
            GridViewRow selectedRow = GridView2.Rows[index];

            String id = selectedRow.Cells[0].Text;
            int anID = Convert.ToInt32(id);
            Display(anID);

        }
    }



    private void Display(int id)
    {
        Byte[] bytes = instructBAL.displayStudentFile(id);
       
        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/pdf";
        Response.BinaryWrite(bytes);
        Response.Flush();
        Response.End();
    }



}