﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
public partial class NotificationsPage : System.Web.UI.Page
{
    //creating a call to the admin business layer
    AdministratorBAL adminBA = new AdministratorBAL();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    string email = Session["email"].ToString();
                    notificationsGrid.DataSource = adminBA.GetNotifications(email);
                    notificationsGrid.DataBind();
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + ex + "');", true);
                }
            }
        }

    }
}