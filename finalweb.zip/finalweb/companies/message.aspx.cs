﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Collections;
using BusinessLogic;

public partial class companies_message : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //for testing purpose set the session
            Session["userID"] = Session["user"];
            Session["userID"] = 9; 
            //Response.Write("<script>alert('Hello "+userID+" TRIP test for review pdf from database binary table');</script>");
        }
    }
    protected void Submit(object sender, EventArgs e)
    {
        //ArrayList selectedemail = new ArrayList();
        //foreach (ListItem name in ListInstructor.Items)
        //{
        //    string li = ListInstructor.SelectedItem.Value;
        //    selectedemail.Add(li);
        //}
        //foreach (ListItem name in ListStudent.Items)
        //{
        //    string li = ListStudent.SelectedItem.Value;
        //    selectedemail.Add(li);
        //}

        //foreach (ListItem item in ListInstructor.Items)
        //{
        //    if (item.Selected)
        //    {
        //        string li = ListInstructor.SelectedItem.Value;
        //        selectedemail.Add(li);
        //    }
        //}

        MailMessage messege = new MailMessage();
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        messege.From = new MailAddress("nbcc.trip@gmail.com");
        foreach (ListItem item in ListInstructor.Items)
        {
            if (item.Selected)
            {
                messege.To.Add(item.Value);
                messege.Subject = subject.Text;
                messege.Body = "Hi " + item.Value + ",<br />" + message.Text;
                messege.IsBodyHtml = true;
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
                client.Send(messege);
            }
        }

        foreach (ListItem item in ListStudent.Items)
        {
            if (item.Selected)
            {
                messege.To.Add(item.Value);
                messege.Subject = subject.Text;
                messege.Body = "Hi " + item.Value + ", <br />" + message.Text;
                messege.IsBodyHtml = true;
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
                client.Send(messege);
            }
        } 
    }
    protected void chkInstructor_CheckedChanged(object sender, EventArgs e)
    {
        if (chkInstructor.Checked)
        {
            BindGrid();
        }
        else
        {
            ListInstructor.Items.Clear();
        }        
    }
    protected void chkStudent_CheckedChanged(object sender, EventArgs e)
    {
        if (chkStudent.Checked)
        {
            BindGrid1();
        }
        else
        {
            ListStudent.Items.Clear();
        } 
    }
    CommonJ cm = new CommonJ();
    private void BindGrid()
    {
        try
        {
            cm.instrucorlistemail(ListInstructor);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    private void BindGrid1()
    {
        try
        {
            cm.studentlistemail(ListStudent);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }


    public void sendEmail(ArrayList emailaddress, string subject, string body)
    {
        MailMessage messege = new MailMessage();
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        messege.From = new MailAddress("nbcc.trip@gmail.com");
        foreach (string a in emailaddress)
        {
            messege.To.Add(a);
            messege.Subject = subject;
            messege.Body = "Hi " + a + ",<br />" + body;
            messege.IsBodyHtml = true;
            client.EnableSsl = true;
            client.UseDefaultCredentials = true;
            client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
            client.Send(messege);
        }               
    }
}