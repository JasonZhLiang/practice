﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Collections;
using System.Security.Cryptography;
using System.Text;
using DataAccessLayer;
using BusinessLogic;

public partial class companies_notificationsend : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }


    CommonJ cm = new CommonJ();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //for testing purpose set the session
            Session["userID"] = Session["user"];
            Session["userID"] = 9;
        }
    }
    protected void Submit(object sender, EventArgs e)
    {
        if (chkInstructor.Checked)
        {
            try
            {
                foreach (ListItem item in ListInstructor.Items)
                {
                    if (item.Selected)
                    {
                        DataTable dt = new DataTable();
                        dt=cm.selectCompanyInfo((int)Session["userID"]);
                        string companyName = dt.Rows[0].Field<string>("companyName");
                        int notificationID = cm.insertnotification(DateTime.Today,message.Text, Convert.ToInt32(item.Value),companyName);
                    }
                }
                SuccessText.Text = "well done!";
                SuccessMessage.Visible = true; 
            }
            catch (Exception ex)
            {
                ErrorMessage.Visible = true;
                FailureText.Text += ex;
            }                
        }

        if (chkStudent.Checked)
        {
            try
            {
                DataTable dt = new DataTable();
                dt = cm.selectCompanyInfo((int)Session["userID"]);
                string companyName = dt.Rows[0].Field<string>("companyName");

                foreach (ListItem item in ListStudent.Items)
                {
                    if (item.Selected)
                    {                      
                        int notificationID = cm.insertnotification(DateTime.Today, message.Text, Convert.ToInt32(item.Value), companyName);
                    }
                }
                SuccessText.Text = "well done!";
                SuccessMessage.Visible = true; 
            }
            catch (Exception ex)
            {
                ErrorMessage.Visible = true;
                FailureText.Text += ex;
            } 
        }


        if ((!chkStudent.Checked) && (!chkInstructor.Checked))
        {
            ErrorMessage.Visible = true;
            FailureText.Text += "you must select at least one recipiant";
        }

    }
    protected void chkInstructor_CheckedChanged(object sender, EventArgs e)
    {
        if (chkInstructor.Checked)
        {
            BindGrid();
            instructorRFV.ValidationGroup = "AllValidators";
        }
        else
        {
            ListInstructor.Items.Clear();
            instructorRFV.ValidationGroup = "";
        }
        SuccessMessage.Visible = false;
        ErrorMessage.Visible = false;
    }
    protected void chkStudent_CheckedChanged(object sender, EventArgs e)
    {
        if (chkStudent.Checked)
        {
            BindGrid1();
            studentRFV.ValidationGroup = "AllValidators";
        }
        else
        {
            ListStudent.Items.Clear();
            studentRFV.ValidationGroup = "";
        }
    }

    private void BindGrid()
    {
        try
        {
            cm.instrucorlist(ListInstructor);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    private void BindGrid1()
    {
        try
        {
            cm.studentlist(ListStudent);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }
}