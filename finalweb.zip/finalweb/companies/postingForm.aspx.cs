﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using BusinessLogic;

public partial class companies_postingForm : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //for testing purpose set the session
        Session["userID"] = Session["user"];
        Session["userID"] = 9;
        if (Page.IsPostBack)
        {
            //Response.Write("<script>$(window).load(function () {$('.se-pre-con').fadeOut(8000);});</script>");           
            //string script = "$(window).load(function () {$('.se-pre-con').fadeOut(8000);});";
            //ClientScript.RegisterStartupScript(this.GetType(), "load", script, true);
        }
    }
    CommonJ cm = new CommonJ();
    protected void Submit(object sender, EventArgs e)
    {
        if (IsValid)
        {
            if (chkUpload.Checked)
            {
                if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
                {
                    ErrorMessage.Visible = true;
                    FailureText.Text += "<br />Error - unable to upload file. Please try again.<br />";
                }
                else
                {
                    try
                    {
                        byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                        FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length); 
                        int fileID = cm.insertuploadfile(FileToUpload.PostedFile.ContentType,fileName.Text.Trim()
                            ,FileToUpload.PostedFile.ContentLength,DateTime.Now,imageBytes,(int)Session["userID"]);


                        DataTable dt = new DataTable();
                        dt=cm.selectCompanyInfo((int)Session["userID"]);
                        int companyID = dt.Rows[0].Field<int>("companyID");

                        bool status = true;
                        int jobPostingID = cm.insertposting(companyID,Convert.ToInt32(classinfo.SelectedValue),jobTitle.Text.Trim(),
                            positionSum.Text, duty.Text,qualification.Text,email.Text,startDate.Text,fileID,
                            status, dueDate.Text, contactPerson.Text, department.Text, companySum.Text, chkCover.Checked);

                        

                        //SEND NOTIFICATION TO EVERY STUDENT WHO IS BELONG TO SELECTED CLASSINFO
                        string companyName = dt.Rows[0].Field<string>("companyName");
                        DataTable dt1 = new DataTable();
                        dt1 = cm.selectstudentbyclassInfo(Convert.ToInt32(classinfo.SelectedValue));
                        string notificationmessage = companyName + " posting a job desacription ";
                        for (int i=0;i<dt1.Rows.Count;i++)
                        {
                            int userID = dt1.Rows[i].Field<int>("userID");
                            int notificationID = cm.insertnotification(DateTime.Today, notificationmessage, userID, companyName);
                        }

                                                                       
                        SuccessText.Text = "well done!";
                        SuccessMessage.Visible = true;  
                    }
                    catch (Exception ex)
                    {
                        ErrorMessage.Visible = true;
                        FailureText.Text += ex;
                    }

                }
            }

            else
            {
                try
                {
                    DataTable dt = new DataTable();
                    dt = cm.selectCompanyInfo((int)Session["userID"]);
                    int companyID = dt.Rows[0].Field<int>("companyID");

                    bool status = true;
                    int jobPostingID = cm.insertposting(companyID, Convert.ToInt32(classinfo.SelectedValue), jobTitle.Text.Trim(),
                        positionSum.Text, duty.Text, qualification.Text, email.Text, startDate.Text, -9999,
                        status, dueDate.Text, contactPerson.Text, department.Text, companySum.Text, chkCover.Checked);

                    SuccessText.Text = "well done!";
                    SuccessMessage.Visible = true;
                }
                catch (Exception ex)
                {
                    ErrorMessage.Visible = true;
                    FailureText.Text += ex;
                }
            }         
        }
        else
        {
            FailureText.Text = "Invalid input.";
            ErrorMessage.Visible = true;
        }       
    }
    protected void chkUpload_CheckedChanged(object sender, EventArgs e)
    {
        SuccessMessage.Visible = false; 
        ErrorMessage.Visible = false;
        if (chkUpload.Checked)
        {
            uploadarea.Visible = true;
            fileNameRFV.ValidationGroup = "AllValidators";
            fileRFV.ValidationGroup = "AllValidators";
        }
        else
        {
            uploadarea.Visible = false;
            fileNameRFV.ValidationGroup = "";
            fileRFV.ValidationGroup = "";
        }
    }
}