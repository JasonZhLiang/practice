﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using DataAccessLayer;
using BusinessLogic;

public partial class companies_postingview : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //for testing purpose set the session
        Session["userID"] = Session["user"];
        Session["userID"] = 9;
        if (!IsPostBack)
        {
            //int userID = (int)Session["userID"];
            //BindGrid();
            //Response.Write("<script>alert('Hello "+userID+" TRIP test for review pdf from database binary table');</script>");
        }
    }

    //move data bind here to improve page performance
    protected void Page_LoadComplete(Object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }

    CommonJ cm = new CommonJ();
    private void BindGrid()
    {
        try
        {
            DataTable dt = new DataTable();
            dt = cm.selectCompanyInfo((int)Session["userID"]);
            int companyID = dt.Rows[0].Field<int>("companyID");
            cm.bindgridviewwithposting(GridView1, companyID);                        
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }

    
    protected void View(object sender, EventArgs e)
    {
        try
        {  
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileCS.ashx?ID="), id);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    
    protected void butSubmit_Click1(object sender, EventArgs e)
    {
        int id1 = Convert.ToInt32(TextBox1.Text);
        //Image2.ImageUrl = "DisplayImg1.ashx?id=" + id1;
    }


    protected void editPosting(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindGrid();
        SuccessText.Text = "Caution:  the jobPostingID, companyID and DueDate are uneditable!";
        SuccessText.Text += "<br />Caution:  the format of date must be keep same!";
        SuccessMessage.Visible = true;
    }
    protected void deletePosting(object sender, GridViewDeleteEventArgs e)
    {
        ErrorMessage.Visible = true;
        FailureText.Text += "You are deleting this post?...Contact with Admin first";
    }

    protected void canclePosting(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        BindGrid();
    }
    protected void updatePosting(object sender, GridViewUpdateEventArgs e)
    {
        //int userID = Int32.Parse(GridView1.DataKeys[e.RowIndex].Value.ToString());
        GridViewRow row = GridView1.Rows[e.RowIndex];
        string column1Value = ((TextBox)(row.Cells[3].Controls[0])).Text;        
        string column6Value = ((TextBox)(row.Cells[5].Controls[0])).Text;
        string column7Value = ((TextBox)(row.Cells[6].Controls[0])).Text;
        string column8Value = ((TextBox)(row.Cells[7].Controls[0])).Text;
        string column9Value = ((TextBox)(row.Cells[8].Controls[0])).Text;
        string column10Value = ((TextBox)(row.Cells[9].Controls[0])).Text;
        //string column11Value = ((TextBox)(row.Cells[10].Controls[0])).Text;
        string column12Value = ((TextBox)(row.Cells[11].Controls[0])).Text;
        string column13Value = ((TextBox)(row.Cells[12].Controls[0])).Text;
        string column14Value = ((TextBox)(row.Cells[13].Controls[0])).Text;
        //bool column5Value = ((CheckBox)(row.Cells[7].Controls[0])).Checked;
        try
        {
            cm.updatingposingitem(column1Value, column6Value, column7Value, column8Value, column9Value, column10Value, column12Value, column13Value, column14Value);
            SuccessText.Text = "well done!";
            SuccessMessage.Visible = true;          
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
        GridView1.EditIndex = -1;
        BindGrid();
    }

    protected void viewresume(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileR.ashx?ID="), id);
            btnClose.Visible = true;
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    protected void viewcoverletter(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileC.ashx?ID="), id);
            btnClose.Visible = true;

        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    protected void viewApplicants(object sender, EventArgs e)
    {
        try
        {
            int jobPostingID = int.Parse((sender as LinkButton).CommandArgument);
            cm.bindgridviewwithapplication(GridView2, jobPostingID);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }        
    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        ltEmbed.Text = "";
        btnClose.Visible = false;
    }
}