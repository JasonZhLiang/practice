﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using BusinessLogic;
public partial class companies_notification : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //for testing purpose set the session
            Session["userID"] = Session["user"];
            Session["userID"] = 9;
        }
    }

    protected void Page_LoadComplete(Object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
    }
    CommonJ cm = new CommonJ();
    public DataTable loadTable()
    {
        try
        {
            return cm.selectnotificationsbyuser((int)Session["userID"]);           
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
            return null;
        }
    }
    private void BindGrid()
    { 
        GridView1.DataSource = loadTable();
        GridView1.DataBind();
    }

    // Fires when Columns heading are clicked
    protected void SortRecords(object sender, GridViewSortEventArgs e)
    {
        DataTable dataTable = loadTable();
        if (dataTable != null)
        {
            DataView dataView = new DataView(dataTable);
            dataView.Sort = getSortExpression(e);
            //GridView1.DataSource = dataTable;
            GridView1.DataSource = dataView;
            GridView1.DataBind();
        }
    }
    private string getSortExpression(GridViewSortEventArgs e)
    {
        string sortDirection = string.Empty;
        // if clicked on the same column twice then let it toggle the sort order, else reset to ascending
        if (ViewState["SortExpression"] != null)
        {
            if (!ViewState["SortExpression"].ToString().Equals(e.SortExpression.ToLower()))
            {
                ViewState["SortDirection"] = null;
            }
        }
        if (ViewState["SortDirection"] != null)
        {
            if (ViewState["SortDirection"].ToString().Equals("ASC"))
            {
                sortDirection = "DESC";
                ViewState["SortDirection"] = "DESC";
            }
            else
            {
                sortDirection = "ASC";
                ViewState["SortDirection"] = "ASC";
            }
        }
        else
        {
            ViewState["SortDirection"] = "ASC";
        }
        ViewState["SortExpression"] = e.SortExpression.ToLower();
        return e.SortExpression + " " + sortDirection;
    }

    protected void ChangePage(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        BindGrid();
    }

    protected void viewContent(object sender, EventArgs e)
    {        
        int id = int.Parse((sender as LinkButton).CommandArgument);
        try
        {
            cm.bindgridviewwithsinglecontent(GridView2, id);
            BindGrid();
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    public void updateisviewed(int id)
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString1"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "update notifications set isViewed=0 where notificationID = @notificationID";
                    cmd.Parameters.AddWithValue("@notificationID", id);
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    //SuccessText.Text = "well done!";
                    //SuccessMessage.Visible = true;                
                }
            }
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    public class commonmethods
    {

    }

}