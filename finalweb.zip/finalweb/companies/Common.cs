﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Security.Cryptography;
using System.Threading;

/// <summary>
/// put all the common method here
/// </summary>
public class Common
{
	public Common()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public int insertuploadfile(string docType, string docName, decimal docSize, byte[] actualFile,int userID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string insertupload = "insert_uploadFile";
            SqlCommand comms = new SqlCommand(insertupload, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@MIME", docType);
            comms.Parameters.AddWithValue("@FileName", docName);
            comms.Parameters.AddWithValue("@Size", docSize);
            comms.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
            comms.Parameters.AddWithValue("@BinaryData", actualFile);
            comms.Parameters.AddWithValue("@userID", userID);
            int fileID = Convert.ToInt32(comms.ExecuteScalar());
            return fileID;
        }
    }


}