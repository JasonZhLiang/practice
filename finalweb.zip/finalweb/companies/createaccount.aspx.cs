﻿using BusinessLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading;
using BusinessLogic;


public partial class companies_createaccount : System.Web.UI.Page
{

    CompanyBL cd = new CompanyBL();
    
    //protected override void OnLoad(EventArgs e)
    //{
    //    if (!IsPostBack)
    //    {
    //        Response.Buffer = false;
    //        Response.Write("<div id='divImage'><div style='float: right;'><img src='~/Images/giphy.gif' />Please wait...</div></div>");
    //        Response.Flush();
    //    }
    //    base.OnLoad(e);
    //}
    //protected override void Render(HtmlTextWriter writer)
    //{
    //    if (!IsPostBack)
    //    {
    //        Response.Clear();
    //        Response.ClearContent();
    //    }
    //    base.Render(writer);
    //}

    //protected void UpdatePanel1_Load(object sender, EventArgs e)
    //{
    //    if (IsPostBack)
    //    {
    //        Thread.Sleep(10000);
    //        TextBox1.Text = "Finished";
    //    }
    //}

    protected void btnLoadData_Click(object sender, EventArgs e)
    {

        //variables to pass into the method
        //string storedProc = "getCompanyList";
        //string text = "companyName";
        //string value = "companyID";
        //string stockMessage = "Select Company";



        //try
        //{
        //    adminBA.populateList(ddCompList, storedProc, text, value, stockMessage);
        //}
        //catch (Exception ex)
        //{
        //    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        //}
    }




    protected void Page_PreInit(Object sender, EventArgs e)
    {
        
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }




    //create a Admin business layer object to call method from that layer to GUI
    AdministratorBAL adminBA = new AdministratorBAL();

    //method to hash the password
    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute  hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into to hexadecimal digits for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    CommonJ cm = new CommonJ();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //for testing purpose set the session
            Session["userID"] = Session["user"];
            Session["userID"] = 9;
            //TextBox1.Text = "First Load";
            //string script = "$(document).ready(function () { $('[id*=btnSubmit]').click(); });";
            //ClientScript.RegisterStartupScript(this.GetType(), "load", script, true);                   
            //variables to pass into the method
            //DataTable dt1 = new DataTable();
            //dt1 = cm.selectCompanyInfo((int)Session["userID"]);
            //string companyName = dt1.Rows[0].Field<string>("fName");
            //SuccessText.Text = "well done!" + companyName;
            //SuccessMessage.Visible = true;
        }        
    }

    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }
            ClearFields(control.Controls);
        }
    }
    

    protected void btnAddCct_Click(object sender, EventArgs e)
    {
        //to check for successful insert
        int returnVal;
        string success = "Company contact has been successfully added!";
        //error message for duplicate record
        string failed = "Company contact already exists in database.";
        //error message for mismatched passwords
        string errMessage = "Passwords do not match. Please enter correct information.";
        //hardcoded userType because this page is specifically for company contact inserting
        int userType = 4;

        try
        {
            string email = txtCctEmail.Text;
            DataTable dt = new DataTable();
            dt=cm.selectCompanyInfo((int)Session["userID"]);
            string companyName = dt.Rows[0].Field<string>("companyName");

            string fname = txtCctFName.Text;
            string lname = txtCctLName.Text;
            string password = txtCctPass.Text;
            string confirm = txtCctConfirm.Text;
            string dept = txtCctDept.Text;
            string telephone = txtCctPhone.Text;

            //this is a means to check for data already existing in the database
            int contactCheck = adminBA.CheckForCompanyContact(email);

            //if the passwords do not match up
            if (password != confirm)
            {
                //display an error message to the user and set focus to the password textbox
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + errMessage + "');", true);
                txtCctPass.Focus();
            }

            //this check is to prevent the insertion of duplicate records
            else if (contactCheck > 0)
            {
                //display error message to the user and clear the form
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + failed + "');", true);
                ClearFields(Page.Form.Controls);
            }
            else
            {
                //else insert into the database
                string hashPass = Encryptor.MD5Hash(password);
                returnVal = adminBA.AddCompanyContact(fname, lname, userType, hashPass, email, companyName, telephone, dept);

                //inserts seem to always return -1 so this is in place to display a success message
                if (returnVal < 0)
                {
                    //send an alert to show insert was successful
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
                    ClearFields(Page.Form.Controls);
                }
            }

        }
        catch (Exception ex)
        {
            //else catch an exception and display it to the user
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        //call dynamic method to clear the page
        ClearFields(Page.Form.Controls);
    }

}
