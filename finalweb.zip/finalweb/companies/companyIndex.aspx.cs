﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Security.Cryptography;
using System.Threading;
using WebSiteForms;
using DataAccessLayer;
using BusinessLogic;
public partial class companies_companyIndex : System.Web.UI.Page
{
    CompanyBL cd = new CompanyBL();
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    CommonJ cm = new CommonJ();
    protected void Page_Load(object sender, EventArgs e)
    {       
        //bool confirmlogin =string.IsNullOrEmpty(Session["email"].ToString());
        if(Session["email"]!=null)
        {
            int usertype = UserTypeCheck(Session["email"].ToString());
            if (usertype != 4)
            {
                Response.Write("<script>alert('Please Login as Company');</script>");
                Response.Redirect("~/Account/Login.aspx");
            }
        }
        else
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            //Response.Write("<script>alert('Please Login to a Company account');</script>");
            //Response.Redirect("/Account/Login.aspx");
        }
        
        if (!IsPostBack)
        {
            //for testing purpose set the session
            Session.Clear();
            Session["userID"] = Session["user"];
            Session["userID"] = 9;
            //Session["email"] = "paul@company.com";
            //Session["fName"] = "Paul";
            //Session["lName"] = "Company";
            MyIFrame.Attributes["src"] = "~/companies/message.aspx?empty=yes";
            try
            {
                lblBadge.Text = cm.countMessage((int)Session["userID"]).ToString();
                if (cm.countMessage((int)Session["userID"]) > 0)
                {
                    lblBadge.Visible = true;
                }

            }
            catch (Exception ex)
            {
                ErrorMessage.Visible = true;
                FailureText.Text += ex;

            }
        }

    }

    public int UserTypeCheck(string email)
    {
        try
        { 
            return cm.UserTypeCheck(email);
        }
        catch (Exception ex)
        {
            FailureText.Text += ex;
            ErrorMessage.Visible = true;
            return -99;
        }
    }


    protected void btn_Upload_Click(object sender, EventArgs e)
    {

    }
    protected void View(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            //int id = int.Parse((sender as LinkButton).CommandArgument);
            int id = 1;
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileCS.ashx?ID="), id);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static string ProtectPassword(string password)
    {
        byte[] bytes = Encoding.Unicode.GetBytes(password);
        byte[] protectedPassword = ProtectedData.Protect(bytes, null, DataProtectionScope.CurrentUser);
        return Convert.ToBase64String(protectedPassword);
    }

    public static string UnprotectPassword(string protectedPassword)
    {
        byte[] bytes = Convert.FromBase64String(protectedPassword);
        byte[] password = ProtectedData.Unprotect(bytes, null, DataProtectionScope.CurrentUser);
        return Encoding.Unicode.GetString(password);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
    }

    protected void load1(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/postingForm.aspx";
    }


    protected void btnToStepOne_OnClick(object sender, EventArgs e)
    {
        //mpeOrder2.Hide();
        //mpeOrder.Show();
    }

    protected void btnToStepThree_OnClick(object sender, EventArgs e)
    {
        //mpeOrder2.Hide();
        //mpeOrder3.Show();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/postingForm.aspx?empty=yes";
    }

    Thread t = new Thread(displayLoader);
    protected void Profile_Click(object sender, EventArgs e)
    {
        t.Start();
    }

    public static void displayLoader()
    {
        System.Threading.Thread.Sleep(5000);
    }
    protected void Posting_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/postingview.aspx?empty=yes";
        t.Start();
        //System.Threading.Thread.Sleep(5000);        
    }
    protected void Message_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/notification.aspx?empty=yes";
        System.Threading.Thread.Sleep(5000);
    }
    protected void Email_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/message.aspx?empty=yes";
        System.Threading.Thread.Sleep(5000);
    }
    protected void SysNotification_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/notificationsend.aspx?empty=yes";
        System.Threading.Thread.Sleep(5000);
    }
    protected void EditPosting_Click(object sender, EventArgs e)
    {

        MyIFrame.Attributes["src"] = "~/companies/postingForm.aspx?empty=yes";
        System.Threading.Thread.Sleep(5000);
    }
    protected void Create_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "~/companies/createaccount.aspx?empty=yes";
        System.Threading.Thread.Sleep(5000);
    }
    protected void Edit_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
    }
    protected void Policy_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
    }
    protected void Support_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
    }
    protected void UpdateButton_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
        MyIFrame.Attributes["src"] = "~/companies/createaccount.aspx?empty=yes";
        FailureText.Text += "hello link";
        ErrorMessage.Visible = true;
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);

    }


}