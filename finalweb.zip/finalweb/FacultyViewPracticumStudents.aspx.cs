﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;

public partial class FacultyViewPracticumStudents : System.Web.UI.Page
{
    InstructorBAL InstructBAL = new InstructorBAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            GridView1.DataSource = InstructBAL.getPlacedStudents();
            GridView1.DataBind();

            GridView2.DataSource = InstructBAL.getNonPlacedStudents();
            GridView2.DataBind();
        }

    }

    protected void DenyPracticum(object sender, EventArgs e)
    {
      //  string id = stuID.Text;

        if (Session["email"] != null)
        {
            String userEmail = Session["email"].ToString();
            String userType = InstructBAL.returnUserType(userEmail);

            int number;

            if ((userType == "1") || (userType == "3"))
            {

                if (int.TryParse(stuID.Text, out number))
                {
                    int success = InstructBAL.DenyPracticum(stuID.Text);
                    Response.Redirect("FacultyViewPracticumStudents");
                }
                else { Label1.Text = "Please enter a Student ID"; }


            }
            else { Label1.Text = "Only Admins and Faculty can deny practicums."; }

            
        }
        else { Label1.Text = "You must be signed in to deny practicums."; }


       
    }
}