﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;


public partial class AddFaculty : System.Web.UI.Page
{
    //create a Admin business layer object to call method from that layer to GUI
    AdministratorBAL adminBA = new AdministratorBAL();

    //method to hash the password
    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute  hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into to hexadecimal digits for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }


    //method to loop through each control on the page
    //and clear/reset the control
    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }

            ClearFields(control.Controls);
        }
    }

    //method to validate email addresses
    private bool IsValidEmail(string checkEmail)
    {
        //Regex To validate Email Address
        Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(checkEmail);

        if (match.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                //variables to pass into the methods
                string storedProc = "getRoleList";
                string text = "roleName";
                string value = "roleID";
                string stockMessage = "Select Role";

                string campusProc = "getCampusList";
                string campusText = "campusName";
                string campusVal = "campusID";
                string campusMessage = "Select Campus";

                try
                {
                    adminBA.populateList(ddRoleList, storedProc, text, value, stockMessage);
                    adminBA.populateList(ddCampusList, campusProc, campusText, campusVal, campusMessage);
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
                }
            }
        }
    }
    protected void btnAddFac_Click(object sender, EventArgs e)
    {

        //variable for password error
        string errMessage = "Passwords do not match, please enter correct information.";
        //variables for success scenario
        int returnVal;
        string success = "Faculty member successfully added!";
        //hardcoding this value because this page is only to add faculty specifically
        int userType = 3;
        //error message for duplicate record
        string failed = "Faculty member already exists in database.";
        //variable for email error
        string errEmail = "Please enter a valid email address.";

        try
        {
            //pass the data from the textboxes on the page to variables
            string email = txtFacEmail.Text;
            string password = txtFacPassword.Text;
            string confirm = txtFacConfirm.Text;
            string fname = txtFacFName.Text;
            string lname = txtFacLName.Text;
            string phone = txtFacPhoneNum.Text;
            int campusID = Convert.ToInt32(ddCampusList.SelectedValue);
            int roleID = Convert.ToInt32(ddRoleList.SelectedValue);
            string startDate = txtRoleStartDate.Text;
            string endDate = txtRoleEndDate.Text;

            //call the method to check if the student exists in the database
            int facultyCheck = adminBA.CheckForFaculty(email);



            //if not a valid email
             if (!IsValidEmail(email))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + errEmail + "');", true);
                txtFacEmail.Focus();
            }

            //if passwords do not match up display an error message
            else if (password != confirm)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + errMessage + "');", true);
                txtFacPassword.Focus();
            }
            else if (facultyCheck > 0)
            {
                //display error message to the user and clear the form 
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + failed + "');", true);
                ClearFields(Page.Form.Controls);
            }
            else
            {
                //else hash the password and then insert the data
                string hashPass = Encryptor.MD5Hash(password);
                returnVal = adminBA.AddFaculty(fname, lname, userType, hashPass, email, phone, campusID, roleID, startDate, endDate);

                //inserts seem to always return -1 so this is a check to let the user know the insert was successful
                if (returnVal < 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
                    ClearFields(Page.Form.Controls);
                }
            }
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        //call method to clear the page
        ClearFields(Page.Form.Controls);
    }
}