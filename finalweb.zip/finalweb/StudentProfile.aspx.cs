﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using Business_Objects;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class StudentProfile : System.Web.UI.Page
{
    
    //method/class to hash the password
    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute  hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into to hexadecimal digits for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    //create an object to call methods from business layer
   StudentBAL studentBA = new StudentBAL();

    //creating a student object
   Student student1 = new Student();

    //creating a resume object
   Resume myResume = new Resume();

    //need variable to be global for method calls
    //hardcoded for now for testing purposes
   //string email = "test@tripp.com";

    //another hardcoded email for testing purposes
   //string email = "StudentAccount@oriontrip.com";
   
    //this is the value that is meant to be passed in 
    //if all functionality was complete
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {

            string email = Session["email"].ToString();

            student1 = studentBA.GetProfileInfo(email);
            myResume = studentBA.GetResumeName(email);

            if (!this.IsPostBack)
            {
                //variables to pass into the method
                string storedProc = "getDropDownResumes";
                string text = "docName";
                string value = "fileID";
                string stockMessage = "Select Resume";

                try
                {
                    studentBA.populateList(ddResumeList, storedProc, text, value, stockMessage, email);
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
                }
            }

            if (student1 != null)
            {
                txtFName.Text = student1.FirstName;
                txtLName.Text = student1.LastName;
                txtLastSignedIn.Text = student1.LastSignedIn;
                txtLinkedInProfile.Text = student1.LinkedIn;
            }

            //displaying default resume filename
            if (myResume != null)
            {
                txtDefaultResume.Text = myResume.ResumeInfo;
            }
        }
    }
    protected void btnChangePassword_Click(object sender, EventArgs e)
    {
            string email = Session["email"].ToString();
            if (txtPassword.Text == "")
            {
                //variable to output and error to the screen
                string needPassword = "Cannot update password with no password typed in. Please enter a password.";

                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + needPassword + "');", true);
            }
            else
            {
                //these next few lines encrypt the password and pass it to the object
                string password = txtPassword.Text;
                string hashPass = Encryptor.MD5Hash(password);
                student1.Password = hashPass;
                student1.Email = email;

                //these variables are for determining success or failure
                int returnVal = -1;
                string updatedSuccessfully = "Password was updated successfully!";
                string unableToUpdate = "Unable to update password. Please try again.";

                returnVal = studentBA.updateStudentPassword(student1);

                //display success and hide the fields again
                if (returnVal < 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + updatedSuccessfully + "');", true);
                    txtPassword.Text = "";
                }
                else //display failure
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + unableToUpdate + "');", true);
                }
        }

    }
    protected void btnLinkedIn_Click(object sender, EventArgs e)
    {
            string email = Session["email"].ToString();
            //creating the values to pass into the object
            student1.LinkedIn = txtLinkedIn.Text;
            student1.Email = email;

            //these variables are for determining success or failure
            int returnVal = -1;
            string updatedSuccessfully = "LinkedIn was updated successfully!";
            string unableToUpdate = "Unable to update LinkedIn. Please try again.";

            //returnVal = studentBA.updateLinkedIn(student1);

            //display success and hide the fields again
            if (returnVal < 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + updatedSuccessfully + "');", true);
                this.Page_Load(null, null);
            }
            else //display failure
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + unableToUpdate + "');", true);
            }
        //clearing the text field
            txtLinkedIn.Text = "";
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            if (FileUploadStudent.HasFile)
            {
                string filename = Path.GetFileName(FileUploadStudent.PostedFile.FileName);
                string fileDocName = FileUploadStudent.FileName;
                string contentType = FileUploadStudent.PostedFile.ContentType;
                string date = DateTime.Today.ToString();
                int fileSize = FileUploadStudent.PostedFile.ContentLength;
                String strID = Session["user"].ToString();
                int id = Convert.ToInt32(strID);

                string fileExtension = Path.GetExtension(fileDocName);

                fileExtension = fileExtension.ToLower();

                if (fileExtension == ".pdf")
                {

                    using (Stream fs = FileUploadStudent.PostedFile.InputStream)
                    {
                        using (BinaryReader br = new BinaryReader(fs))
                        {
                            byte[] bytes = br.ReadBytes((Int32)fs.Length);
                            int success = studentBA.uploadFiles(fileExtension, filename, fileSize, date, bytes, id);


                            lblFail.ForeColor = System.Drawing.Color.Blue;
                            lblFail.Text = filename + " successfully uploaded";

                        }
                    }
                }
                else
                {
                    lblFail.ForeColor = System.Drawing.Color.Red;
                    lblFail.Text = "Please upload a pdf file.";
                }

            }
            else
            {
                lblFail.ForeColor = System.Drawing.Color.Red;
                lblFail.Text = "Please choose a pdf file.";
            }

        }
        else
        {
            lblFail.ForeColor = System.Drawing.Color.Red;
            lblFail.Text = "You must be signed in.";
        }
    }
    protected void btnDefaultResume_Click(object sender, EventArgs e)
    {
        string email = Session["email"].ToString();

        foreach (ListItem li in ddResumeList.Items)
        {
            if (li.Selected == true)
            {
                if (studentBA.UpdateDefaultResume(email, Convert.ToInt32(li.Value)) == 1)
                {
                    lblTest.Text = "You have sucessfully updated your default resume";
                }
                else
                {
                    lblTest.Text = "";
                }
            }
        }
    }
}