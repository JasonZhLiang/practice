﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using BusinessLogic;
using System.Text;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

public partial class AddCompany : System.Web.UI.Page
{
    //create a Admin business layer object to call method from that layer to GUI
    AdministratorBAL adminBA = new AdministratorBAL();

    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }
            ClearFields(control.Controls);
        }
    }
    //method to validate email
    private bool IsValidEmail(string checkEmail)
    {
        //Regex To validate Email Address
        Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
        Match match = regex.Match(checkEmail);

        if (match.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //method to hash password
    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute  hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into to hexadecimal digits for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {

            string storedProc = "getProvinceList";
            string text = "provinceName";
            string value = "provinceID";
            string stockMessage = "Select Province";

            if (!Page.IsPostBack)
            {
                try
                {
                    adminBA.populateList(ddProvList, storedProc, text, value, stockMessage);
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
                }
            }

            //set the panel/form to add contacts to be not
            //visible on page load, only display once the company has been added
            contactPanel.Visible = false;
        }
    }

    protected void btnAddComp_Click(object sender, EventArgs e)
    {
        //to check for successful insert
        int returnVal;
        string success = "Company has been successfully added!";
        //error message for duplicate record
        string failed = "Company already exists in database.";

        try
        {

        //pass all the values from the textboxes to variables
        string phoneNum = txtCompanyPhone.Text;
        string companyName = txtCompanyName.Text;
        string streetAddress = txtStreetAddress.Text;
        string city = txtCity.Text;
        string postal = txtPostalCode.Text;
        string province = ddProvList.SelectedValue;

        //this is a means to check for data already existing in the database
        int companyCheck = adminBA.CheckForCompany(companyName);

        //this check is to prevent the insertion 
        if (companyCheck > 0)
        {
            //display error message to the user and set focus on the company name
            ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + failed + "');", true);
            ClearFields(Page.Form.Controls);
        }
        else
        {
            //else insert into the database
            returnVal = adminBA.AddCompany(phoneNum, companyName, streetAddress, city, postal, province);

            //inserts seem to always return -1 so this is in place to display a success message
            if (returnVal < 0)
            {
                //send an alert to show insert was successful
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
                ClearFields(Page.Form.Controls);

                //display the contact panel to the user
                contactPanel.Visible = true;
                companyPanel.Visible = false;

                //setting the company name for the company contact being added
                txtCctCompany.Text = companyName;

            }
        }

        }
        catch (Exception ex)
        {
            //else catch an exception and display it to the user
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }

    protected void btnAddCct_Click(object sender, EventArgs e)
    {
        //to check for successful insert
        int returnVal;
        string success = "Company contact has been successfully added!";
        //error message for duplicate record
        string failed = "Company contact already exists in database.";
        //error message for mismatched passwords
        string errMessage = "Passwords do not match. Please enter correct information.";
        //hardcoded userType because this page is specifically for company contact inserting
        int userType = 4;
        //variable for email error
        string errEmail = "Please enter a valid email address.";

        try
        {
            //pass the data from the textboxes on the page to variables
            string email = txtCctEmail.Text;
            string companyName = txtCctCompany.Text; 
            string fname = txtCctFName.Text;
            string lname = txtCctLName.Text;
            string password = txtCctPass.Text;
            string confirm = txtCctConfirm.Text;
            string dept = txtCctDept.Text;
            string telephone = txtCctPhone.Text;

            //this is a means to check for data already existing in the database
            int contactCheck = adminBA.CheckForCompanyContact(email);

            //if the passwords do not match up
            if (!IsValidEmail(email))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + errEmail + "');", true);
                txtCctEmail.Focus();
            }

            //if passwords do not match up display an error message
            else if (password != confirm)
            {
                //display an error message to the user and set focus to the password textbox
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + errMessage + "');", true);
                txtCctPass.Focus();
            }

            //this check is to prevent the insertion of duplicate records
            if (contactCheck > 0)
            {
                //display error message to the user and clear the form
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + failed + "');", true);
                ClearFields(Page.Form.Controls);
            }
            else
            {
                //else insert into the database
                string hashPass = Encryptor.MD5Hash(password);
                returnVal = adminBA.AddCompanyContact(fname, lname, userType, hashPass, email, companyName, telephone, dept);

                //inserts seem to always return -1 so this is in place to display a success message
                if (returnVal < 0)
                {
                    //send an alert to show insert was successful
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
                    ClearFields(Page.Form.Controls);
                    companyPanel.Visible = true;
                }
            }

        }
        catch (Exception ex)
        {
            //else catch an exception and display it to the user
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }
    protected void btnResetComp_Click(object sender, EventArgs e)
    {
        //call dynamic method to clear the page
        ClearFields(Page.Form.Controls);
    }
}