﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;

public partial class UpdateRoles : System.Web.UI.Page
{
    //create an admin business layer object
    AdministratorBAL adminBA = new AdministratorBAL();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                string storedProc = "getFacultyNameAndEmailOnly";
                string text = "Name";
                string value = "email";
                string userMessage = "Select A User";

                try
                {
                    adminBA.populateList(ddUserList, storedProc, text, value, userMessage);
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
                }
                updateInfoPanel.Enabled = false;
            }
        }
    }
    protected void btnSelect_Click(object sender, EventArgs e)
    {
        string email = ddUserList.SelectedValue;

            try
            {
                adminBA.getRoleInformation(email, txtRole, txtRoleStart, txtRoleEnd, txtName);
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
            }

        updateInfoPanel.Enabled = true;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        //variable for the return from the update
        int updateSuccess = -1;

        //variables for different success or failure scenarios
        string needRole = "The role cannot be empty. Please enter a role.";
        string needDate = "The role must be tied to a start and end date. Please verify both have been entered.";
        string successful = " The update was successful.";
        string failedToInsert = " The update failed. Please try again.";


        //variables created from pulling what is in the fields on the page
        string email = ddUserList.SelectedValue;
        string startDate = txtRoleStart.Text;
        string endDate = txtRoleEnd.Text;
        string roleName = txtRole.Text;

        if (txtRole.Text == "")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "errAlert", "alert('" + needRole + "');", true);
            txtRole.Focus();
        }
        else if (txtRoleStart.Text == "")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "errAlert", "alert('" + needDate + "');", true);
            txtRoleStart.Focus();
        }
        else if (txtRoleEnd.Text == "")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "errAlert", "alert('" + needDate + "');", true);
            txtRoleEnd.Focus();
        }
        else
        {
            updateSuccess = adminBA.updateRoleForFaculty(email, startDate, endDate, roleName);

            if (updateSuccess < 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + successful + "');", true);
                ddUserList.SelectedIndex = -1;
                txtName.Text = "";
                txtRole.Text = "";
                txtRoleStart.Text = "";
                txtRoleEnd.Text = "";
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + failedToInsert + "');", true);
            }
        }


    }
}