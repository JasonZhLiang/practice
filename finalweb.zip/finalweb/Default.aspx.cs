﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Upload_Click(object sender, EventArgs e)
    {
        if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
        {
            lit_Status.Text = "<br />Error - unable to upload file. Please try again.<br />";
        }
        else
        {
            using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionStringUploadFile"].ConnectionString))
            {
                try
                {
                    const string SQL = "INSERT INTO [uploadfile] ([FileName], [DateTimeUploaded], [MIME], [BinaryData]) VALUES (@FileName, @DateTimeUploaded, @MIME, @BinaryData)";
                    SqlCommand cmd = new SqlCommand(SQL, Conn);

                    //add the value to variable
                    cmd.Parameters.AddWithValue("@FileName", FileName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MIME", FileToUpload.PostedFile.ContentType);
                    
                    //below 2 lines used to hold the file to a byte array.
                    byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                    FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
                    
                    cmd.Parameters.AddWithValue("@BinaryData", imageBytes);
                    cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);

                    Conn.Open();
                    lit_Status.Text = "<br />connection successfully opened <br />";
                    cmd.ExecuteNonQuery();
                    lit_Status.Text += "<br />File successfully uploaded - thank you.<br />";
                    Conn.Close();
                }
                catch (Exception ex)
                {
                    lit_Status.Text += ex;                   
                    Conn.Close();
                }
            }
        }
    }
    

    protected void butSubmit_Click(object sender, EventArgs e)
    {
        SqlConnection connection = null;
        try
        {
           
            Byte[] imgByte = null;
            if (FileUpload1.HasFile && FileUpload1.PostedFile != null)
            {
                HttpPostedFile File = FileUpload1.PostedFile;
                imgByte = new Byte[File.ContentLength];
                File.InputStream.Read(imgByte, 0, File.ContentLength);
            }
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionStringUploadFile"].ConnectionString.ToString());

            connection.Open();
            string sql = "INSERT INTO Table1(title,image) VALUES(@theTitle, @theImage) SELECT @@IDENTITY";
            SqlCommand cmd = new SqlCommand(sql, connection);
            cmd.Parameters.AddWithValue("@theTitle", txtTitle.Text);
            cmd.Parameters.AddWithValue("@theImage", imgByte);
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            lblStatus.Text = String.Format("ID is {0}", id);

            Image1.ImageUrl = "~/DisplayImg.ashx?id=" + id;
        }
        catch
        {
            lblStatus.Text = "There was an error";
        }
        finally
        {
            connection.Close();
        }
    }

    protected void butSubmit_Click2(object sender, EventArgs e)
    {
        int id1 = Convert.ToInt32(TextBox2.Text);
        View1.ID = "~/DisplayTxt.ashx?id=" + id1;
    }
}