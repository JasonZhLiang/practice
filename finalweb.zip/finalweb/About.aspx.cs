﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

public partial class About : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Upload_Click(object sender, EventArgs e)
    {
        if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
        {
            lit_Status.Text = "<br />Error - unable to upload file. Please try again.<br />";
        }
        else
        {
            using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    const string SQL = "INSERT INTO [UploadedFile] ([docType], [docName], [docSize], [dateUploaded], [actualFile]) VALUES (@MIME, @FileName, @Size, @DateTimeUploaded, @BinaryData)";
                    SqlCommand cmd = new SqlCommand(SQL, Conn);
                    cmd.Parameters.AddWithValue("@MIME", FileToUpload.PostedFile.ContentType);
                    cmd.Parameters.AddWithValue("@FileName", FileName.Text.Trim());                   
                    cmd.Parameters.AddWithValue("@Size", FileToUpload.PostedFile.ContentLength);
                    cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
                    byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                    FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
                    cmd.Parameters.AddWithValue("@BinaryData", imageBytes);


                    Conn.Open();
                    lit_Status.Text = "<br />connection successfully opened <br />";
                    cmd.ExecuteNonQuery();
                    lit_Status.Text += "<br />File successfully uploaded - thank you.<br />";
                    Conn.Close();
                }
                catch (Exception ex)
                {
                    lit_Status.Text += ex;
                    Conn.Close();
                }
            }
        }
    }

}