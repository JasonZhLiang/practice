﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class InstructorUploadFile : System.Web.UI.Page
{
    
    InstructorBAL instructBAL = new InstructorBAL();

    protected void Upload(object sender, EventArgs e)
    {
        if (Session["user"] != null)
        {
            if (FileUpload1.HasFile)
            {
                string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                string fileDocName = FileUpload1.FileName;
                string contentType = FileUpload1.PostedFile.ContentType;
                string date = DateTime.Today.ToString();
                int fileSize = FileUpload1.PostedFile.ContentLength;
                String strID = Session["user"].ToString();
                int id = Convert.ToInt32(strID);

                string fileExtension = Path.GetExtension(fileDocName);

                fileExtension = fileExtension.ToLower();

                if (fileExtension == ".pdf")
                {

                    using (Stream fs = FileUpload1.PostedFile.InputStream)
                    {
                        using (BinaryReader br = new BinaryReader(fs))
                        {
                            byte[] bytes = br.ReadBytes((Int32)fs.Length);
                            int success = instructBAL.uploadFiles(fileExtension, filename, fileSize, date, bytes, id);


                            lblFail.ForeColor = System.Drawing.Color.Blue;
                            lblFail.Text = filename + " successfully uploaded";

                        }
                    }
                }
                else
                {
                    lblFail.ForeColor = System.Drawing.Color.Red;
                    lblFail.Text = "Please upload a pdf file.";
                }

            }
            else
            {
                lblFail.ForeColor = System.Drawing.Color.Red;
                lblFail.Text = "Please choose a pdf file.";
            }

        }
        else
        {
            lblFail.ForeColor = System.Drawing.Color.Red;
            lblFail.Text = "You must be signed in.";
        }
    }



    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
    }

  









}