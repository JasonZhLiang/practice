﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using Business_Objects;

public partial class AddProgramsAndClasses : System.Web.UI.Page
{
    //create an admin business layer object
    AdministratorBAL adminBA = new AdministratorBAL();

    //create a practicum object
    Practicum practicum1 = new Practicum();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //the campus dropdowns
            string storedProc1 = "getCampusList";
            string text1 = "campusName";
            string value1 = "campusID";
            string stockMessage1 = "Select Campus Info";

            string storedProc = "getCampusList";
            string text = "campusName";
            string value = "campusID";
            string stockMessage = "Select Campus Info";

            //the program dropdowns
            string storedProc2 = "getProgramList";
            string text2 = "programName";
            string value2 = "abbreviation";
            string progMessage = "Select Program Info";

            string storedProc3 = "getProgramList";
            string text3 = "programName";
            string value3 = "abbreviation";
            string progMessage1 = "Select Program Info";

            //the academic year
            string yearProc = "getAcademicYears";
            string yrTxt = "academicyear";
            string yrVal = "yearID";
            string yrMessage = "Select an Academic Year";

            //the instructor
            string instructProc = "getPracticumInstructors";
            string instructTxt = "InstructorName";
            string instructVal = "userID";
            string instructMessage = "Select an Instructor";

            //the class information
            string classProc = "getClassInformation";
            string classText = "classinformation";
            string classValue = "classInfoID";
            string classMessage = "Select Class Info";

            try
            {
                adminBA.populateList(ddCampusList, storedProc1, text1, value1, stockMessage1);
                adminBA.populateList(ddProgList, storedProc2, text2, value2, progMessage);
                adminBA.populateList(ddCampuses, storedProc, text, value, stockMessage);
                adminBA.populateList(ddPrograms, storedProc3, text3, value3, progMessage1);
                adminBA.populateList(ddAcamedicYrs, yearProc, yrTxt, yrVal, yrMessage);
                adminBA.populateList(ddInstructor, instructProc, instructTxt, instructVal, instructMessage);
                adminBA.populateList(ddClassInformation, classProc, classText, classValue, classMessage);
            }
            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
            }
        }
    }

    protected void btnAddProg_Click(object sender, EventArgs e)
    {
        //variable for error message if either textbox is blank
        string errorCheck = "Either Program Abbreviaton or Program Name is blank. Please fill out the fields appropriately.";

        //variable for abbreviation to perform check on textbox
        string abbreviation = txtProgCode.Text;
        string progName = txtNewProgram.Text;

        //variable for error if abbreviation is too long
        string abbrError = "The abbreviation/program code is too long. Must be no greater than 4 characters.";

        //variable for successful insert/failed insert
        string insertSuccessful = "Program successfully added to the system!";
        string failedInsert = "Program could not be added to database.";

        //check to see if the textboxes are empty
        if ((abbreviation.Length == 0) || (progName.Length == 0))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + errorCheck + "');", true);

        }
        //eise if the abbreviation is longer than 4 characters
        else if (abbreviation.Length > 4)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + abbrError + "');", true);
        }
        else
        {
            int insertProgSuccess = adminBA.addNewPrograms(abbreviation, progName);

            if (insertProgSuccess < 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + insertSuccessful + "');", true);
                txtNewProgram.Text = "";
                txtProgCode.Text = "";
                //this line automatically refreshes the page so that the dropdowns update
                Response.Redirect("AddStudents.aspx");
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + failedInsert + "');", true);
            }
        }
    }

    protected void btnAddClass_Click(object sender, EventArgs e)
    {
        //variables for various error messages
        string noCampus = "No campus was selected. Please select a campus.";
        string noProgram = "No program was selected. Please selected a program.";
        string noStartDate = "No start date entered. Please enter a start date.";
        string noEndDate = "No end date entered. Please enter an end date.";

        if (ddCampusList.SelectedIndex == -1)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + noCampus + "');", true);
            ddCampusList.Focus();
        }
        else if (ddProgList.SelectedIndex == -1)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + noProgram + "');", true);
            ddProgList.Focus();
        }
        else if (txtStartDate.Text == "")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + noStartDate + "');", true);
            txtStartDate.Focus();
        }
        else if (txtEndDate.Text == "")
        {
            ClientScript.RegisterStartupScript(this.GetType(), "failedAlert", "alert('" + noEndDate + "');", true);
            txtEndDate.Focus();
        }
        else
        {
            //variable for successful insert/failed insert
            string insertSuccessful = "Class successfully added to the system!";
            string failedInsert = "Class could not be added to database.";

            string abbrev = ddProgList.SelectedValue;
            int campusID = Convert.ToInt32(ddCampusList.SelectedValue);
            string sDate = txtStartDate.Text;
            string eDate = txtEndDate.Text;

            int insertClassSuccess = adminBA.addNewClassInfo(abbrev, campusID, sDate, eDate);

            if (insertClassSuccess < 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + insertSuccessful + "');", true);
                ddProgList.SelectedIndex = -1;
                ddCampusList.SelectedIndex = -1;
                txtStartDate.Text = "";
                txtEndDate.Text = "";
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + failedInsert + "');", true);
            }
        }
    }

    protected void btnAddPracticum_Click(object sender, EventArgs e)
    {
        //various variables for success or failure
        string cannotBeEmpty = "No fields an be empty when inserting a practicum. Please ensure all fields are selected/entered properly.";
        int returnVal = -1; //this is for insertion purposes
        int checkReturn = 0; //this is to see if practicums exist already
        string practicumAdded = "Practicum was successfully added!";
        string unableToAdd = "Unable to add practicum. Please try again!";
        string practicumExists = "Practicum already exists for that class!";

        //if any of the fields are empty or nothing is selected display an error message to the user
        if ((ddAcamedicYrs.SelectedIndex == -1) || (ddCampuses.SelectedIndex == -1) || (ddClassInformation.SelectedIndex == -1))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + cannotBeEmpty + "');", true);
        }
        else if ((ddPrograms.SelectedIndex == -1) || (ddInstructor.SelectedIndex == -1) || (txtPractStDate.Text == "") || (txtPractEndDate.Text == ""))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + cannotBeEmpty + "');", true);
        }
        else
        {
         //else populate the practicum object with the campus, program code, and year ID to check if the practicum exists already   
            practicum1.CampusID = ddCampuses.SelectedIndex;
            practicum1.ProgCode = ddPrograms.SelectedIndex;
            practicum1.YearID = ddAcamedicYrs.SelectedIndex;

            checkReturn = adminBA.CheckForPracticum(practicum1);

            //if the check returns a row then display an error message to the user
            if (checkReturn > 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + checkReturn + "');", true);
            }
            else
            {
                //else populate the practicum object with the full members of the practicum object
                practicum1.CampusID = ddCampuses.SelectedIndex;
                practicum1.ProgCode = ddPrograms.SelectedIndex;
                practicum1.YearID = ddAcamedicYrs.SelectedIndex;
                practicum1.StartDate = txtPractStDate.Text;
                practicum1.EndDate = txtPractEndDate.Text;
                practicum1.PracticumInstructor = ddInstructor.SelectedIndex;
                practicum1.ClassInfoID = ddClassInformation.SelectedIndex; 

                //insert the practicum
                returnVal = adminBA.insertNewPracticums(practicum1);

                //if the return is -1, which it should be, inserts seem to always return -1
                //display a success message and reset the "form"s
                if (returnVal < 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + practicumAdded + "');", true);
                    ddClassInformation.SelectedIndex = -1;
                    ddCampuses.SelectedIndex = -1;
                    ddAcamedicYrs.SelectedIndex = -1;
                    ddInstructor.SelectedIndex = -1;
                    ddPrograms.SelectedIndex = -1;
                    txtPractStDate.Text = "";
                    txtPractEndDate.Text = "";
                }
                else
                {
                    //else the insert did not work and display an error message
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + unableToAdd + "');", true);
                }
            }
        }
    }
    protected void btnClrPrg_Click(object sender, EventArgs e)
    {
        txtProgCode.Text = "";
        txtNewProgram.Text = "";
    }
    protected void btnClrClss_Click(object sender, EventArgs e)
    {
        ddCampusList.SelectedIndex = -1;
        ddProgList.SelectedIndex = -1;
        txtStartDate.Text = "yyyy-mm-dd";
        txtEndDate.Text = "yyyy-mm-dd";
    }
    protected void btnClrPrctm_Click(object sender, EventArgs e)
    {
        txtPractStDate.Text = "yyyy-mm-dd";
        txtPractEndDate.Text = "yyy-mm-dd";
        ddCampuses.SelectedIndex = -1;
        ddPrograms.SelectedIndex = -1;
        ddClassInformation.SelectedIndex = -1;
        ddInstructor.SelectedIndex = -1;
        ddAcamedicYrs.SelectedIndex = -1;
    }
}