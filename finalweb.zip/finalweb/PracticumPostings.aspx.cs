﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Web.UI.WebControls;
using BusinessLogic;

public partial class PracticumPostings : System.Web.UI.Page
{
    StudentBAL StudentBA = new StudentBAL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                GridViewPostings.DataSource = StudentBA.GetPostings();
            }
        }
    }

    public void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ApplyButton")
        {
            // retrieve the row index stored in the command argument property
            int index = Convert.ToInt32(e.CommandArgument);

            GridViewRow row = GridViewPostings.Rows[index];
        }
    }
}

