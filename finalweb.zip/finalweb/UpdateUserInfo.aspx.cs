﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

public partial class UpdateUserInfo : System.Web.UI.Page
{
    //create global AdminBAL object to call methods from that layer
    AdministratorBAL adminBA = new AdministratorBAL();

    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            //compute  hash from the bytes of text
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            //get hash result after compute it
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                //change it into to hexadecimal digits for each byte
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    //method to validate password from user input
    private bool IsValidPassword(string checkPassword)
    {
        //Regex To validate Email Address
        Regex regex = new Regex(@"^(?=(.*\d){2})(?=.*[a-zA-Z])[0-9a-zA-Z]{8,16}$");
        Match match = regex.Match(checkPassword);

        if (match.Success)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    refreshUserInfo();
                }
                catch (Exception ex)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + ex + "');", true);
                }
            }
        }
    }

    //small helper method to refresh user info 
    public void refreshUserInfo()
    {
        userGrid.DataSource = adminBA.getAllAccounts();
        userGrid.DataBind();
    }

    protected void userGrid_RowEditing(object sender, GridViewEditEventArgs e)
    {
       userGrid.EditIndex = e.NewEditIndex;
       refreshUserInfo();

    }
    protected void userGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

        //this variables are strictly to indicate whether the update has been successful or not
        int success = -1;
        string successMessage = "The user has been successfully updated.";
        string errorMessage = "The update has failed.";

        //variable for messages around isValidPassword method, success, failure, etc
        string invalidPassMessage = "The password is invalid. Must be between 8 and 16 characters and include at least 2 numbers.";

        //users are ordered by userID in query so assigning the userID the value of the row index
        //so that the update statement knows to match the userID of the user
        int userID = Convert.ToInt32(userGrid.DataKeys[e.RowIndex].Value);

        //casting the columns as textboxes so that the values can be passed down the layers
        //into the update stored procedure
        TextBox txtEmail = (TextBox)userGrid.Rows[e.RowIndex].Cells[2].Controls[0];
        TextBox txtFName = (TextBox)userGrid.Rows[e.RowIndex].Cells[3].Controls[0];
        TextBox txtLName = (TextBox)userGrid.Rows[e.RowIndex].Cells[4].Controls[0];
        TextBox txtPassword = (TextBox)userGrid.Rows[e.RowIndex].Cells[5].Controls[0];
        CheckBox chkActive = (CheckBox)userGrid.Rows[e.RowIndex].Cells[6].Controls[0];
        

        //passing values from textboxes to variables simply because the boolean of the checkbox
        //needs to be an int for update purposes....1 = checked/active user 0 = unchecked/inactive user
        string email = txtEmail.Text;
        string fname = txtFName.Text;
        string lname = txtLName.Text;
        string password = txtPassword.Text;
        int isChecked = Convert.ToInt32(chkActive.Checked);


        //md5 hashs always result in a 32 bit hash, knowing the restriction on password length in 
        //the initial form to add users is less than this, I can prevent the admin account from entering
        //a password that is longer than allowed and use the length of the hash to determine if the password
        //has been changed or not 
        if (password.Length == 32)
        {
            //using the integer value to see if the update works or not
            success = adminBA.updateAccount(userID, email, fname, lname, txtPassword.Text, isChecked);

            if (success < 0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + successMessage + "');", true);
            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + errorMessage + "');", true);
            }
        }

        else
        {
            if (!IsValidPassword(password))
            {
                ClientScript.RegisterStartupScript(this.GetType(), "invalidAlert", "alert('" + invalidPassMessage + "');", true);
            }
            else
            {
                //hash the password
                string hashPassword = Encryptor.MD5Hash(password);

                success = adminBA.updateAccount(userID, email, fname, lname, hashPassword, isChecked);

                if (success < 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + successMessage + "');", true);
                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + errorMessage + "');", true);
                }
            }
        }
        userGrid.EditIndex = -1;
        refreshUserInfo();
    }
    protected void userGrid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        userGrid.EditIndex = -1;
        refreshUserInfo();
    }  


}