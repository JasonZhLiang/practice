﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Security.Cryptography;
using System.Threading;

/// <summary>
/// put all the common method here
/// </summary>
public class CommonJ
{
    public CommonJ()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static int insertuploadfile(string docType, string docName, decimal docSize, byte[] actualFile, int userID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string insertupload = "insert_uploadFile";
            SqlCommand comms = new SqlCommand(insertupload, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@MIME", docType);
            comms.Parameters.AddWithValue("@FileName", docName);
            comms.Parameters.AddWithValue("@Size", docSize);
            comms.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
            comms.Parameters.AddWithValue("@BinaryData", actualFile);
            comms.Parameters.AddWithValue("@userID", userID);
            int fileID = Convert.ToInt32(comms.ExecuteScalar());
            return fileID;
        }
    }

    public int insertuploadfile(string docType, string docName, decimal docSize, DateTime dateupload, byte[] actualFile, int userID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string insertupload = "Insert_uploadFile";
            SqlCommand comms = new SqlCommand(insertupload, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@MIME", docType);
            comms.Parameters.AddWithValue("@FileName", docName);
            comms.Parameters.AddWithValue("@Size", docSize);
            comms.Parameters.AddWithValue("@DateTimeUploaded", dateupload);
            comms.Parameters.AddWithValue("@BinaryData", actualFile);
            comms.Parameters.AddWithValue("@userID", userID);
            int fileID = Convert.ToInt32(comms.ExecuteScalar());
            Conn.Close();
            return fileID;

            //const string SQL = "INSERT INTO [uploadedfile] ([docType], [docName], [docSize], [dateUploaded], [actualFile],[userID]) VALUES (@MIME, @FileName, @Size, @DateTimeUploaded, @BinaryData,@userID)";
            //SqlCommand cmd = new SqlCommand(SQL, Conn);
            //cmd.Parameters.AddWithValue("@MIME", FileToUpload.PostedFile.ContentType);
            //cmd.Parameters.AddWithValue("@FileName", fileName.Text.Trim());
            //cmd.Parameters.AddWithValue("@Size", FileToUpload.PostedFile.ContentLength);
            //cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
            //byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
            //FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
            //cmd.Parameters.AddWithValue("@BinaryData", imageBytes);
            //cmd.Parameters.AddWithValue("@userID", Session["userID"]);

            //string insertupload = "insert_uploadFile";
            //SqlCommand comms = new SqlCommand(insertupload, Conn);
            //comms.CommandType = System.Data.CommandType.StoredProcedure;
            //comms.Parameters.AddWithValue("@MIME", );
            //comms.Parameters.AddWithValue("@FileName", );
            //comms.Parameters.AddWithValue("@Size", );
            //comms.Parameters.AddWithValue("@DateTimeUploaded", );
            //byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
            //FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
            //comms.Parameters.AddWithValue("@BinaryData", imageBytes);
            //comms.Parameters.AddWithValue("@userID", );
            //int fileID = Convert.ToInt32(comms.ExecuteScalar());
        }
    }

    //get the last insert identity value which is fileID.
    //string sql1 = "SELECT SCOPE_IDENTITY() FROM uploadedfile";// so using two sql command return the ID
    //SqlCommand comm1 = new SqlCommand(sql1, Conn);
    //int fileID = Convert.ToInt32(comm1.ExecuteScalar()); //;

    //get the companyID value which by userID.
    //string sql2 = "SELECT companyID FROM companycontact WHERE userID =@userID";                               
    //SqlCommand comm2 = new SqlCommand(sql2, Conn);
    //comm2.Parameters.AddWithValue("@userID", Session["userID"]);
    //int companyID = Convert.ToInt32(comm2.ExecuteScalar());

    public int insertposting(int companyID, int classInfoID, string title, string description, string duties, string Qualifications, string ContactEmail, string datePosted,
        int attachedFileID, bool statusID, string dateDue, string ContactPerson, string department, string other, bool coverLetterRequested)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            //string insertpost = "INSERT INTO [posting] ([companyID],[classInfoID],[title],[description],[duties],[Qualifications],[ContactEmail],[datePosted],[attachedFileID],[statusID],[dateDue],[ContactPerson],[department],[other],[coverLetterRequested]) VALUES (@companyID,@classInfoID,@title,@description,@duties,@Qualifications,@ContactEmail,@datePosted,@attachedFileID,@dateDue,@ContactPerson,@department,@other,@coverLetterRequested)";
            string insertpost = "Insert_posting";
            SqlCommand comms = new SqlCommand(insertpost, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@companyID", companyID);
            comms.Parameters.AddWithValue("@classInfoID", classInfoID);
            comms.Parameters.AddWithValue("@title", title);
            comms.Parameters.AddWithValue("@description", description);
            comms.Parameters.AddWithValue("@duties", duties);
            comms.Parameters.AddWithValue("@Qualifications", Qualifications);
            comms.Parameters.AddWithValue("@ContactEmail", ContactEmail);
            comms.Parameters.AddWithValue("@datePosted", datePosted);
            comms.Parameters.AddWithValue("@attachedFileID", attachedFileID);
            comms.Parameters.AddWithValue("@statusID", statusID ? 1 : 0);
            comms.Parameters.AddWithValue("@dateDue", dateDue);
            comms.Parameters.AddWithValue("@ContactPerson", ContactPerson);
            comms.Parameters.AddWithValue("@department", department);
            comms.Parameters.AddWithValue("@other", other);
            comms.Parameters.AddWithValue("@coverLetterRequested", coverLetterRequested ? 1 : 0);
            int postingID = Convert.ToInt32(comms.ExecuteScalar());
            Conn.Close();
            return postingID;


            //string insertPosting = "INSERT INTO [posting] ([companyID],[classInfoID],[title],[description],[duties],[Qualifications],[ContactEmail],[datePosted],[attachedFileID],[dateDue],[coverLetterRequested]) VALUES (@companyID,@classInfoID,@title,@description,@duties,@Qualifications,@ContactEmail,@datePosted,@attachedFileID,@dateDue,@coverletter)";
            //SqlCommand comm3 = new SqlCommand(insertPosting, Conn);
            //comm3.Parameters.AddWithValue("@companyID", companyID);
            //comm3.Parameters.AddWithValue("@classInfoID", classinfo.SelectedValue);
            //comm3.Parameters.AddWithValue("@title", jobTitle.Text.Trim());
            //comm3.Parameters.AddWithValue("@description", positionSum.Text);
            //comm3.Parameters.AddWithValue("@duties", duty.Text);
            //comm3.Parameters.AddWithValue("@Qualifications", qualification.Text);
            //comm3.Parameters.AddWithValue("@ContactEmail", email.Text);
            //comm3.Parameters.AddWithValue("@datePosted", startDate.Text);
            //comm3.Parameters.AddWithValue("@attachedFileID", fileID);
            //comm3.Parameters.AddWithValue("@dateDue", dueDate.Text);
            //int checkcover = chkCover.Checked? 1 : 0;
            ////comm3.Parameters.AddWithValue("@coverletter", chkCover.Checked);
            //comm3.Parameters.AddWithValue("@coverletter", checkcover);
            //int insertPostingint = Convert.ToInt32(comm3.ExecuteNonQuery());                                
            //Conn.Close();
        }
    }

    public int insertnotification(DateTime dateSend, string message, int userID, string link)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string insertnotification = "Insert_notification";
            SqlCommand comms = new SqlCommand(insertnotification, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@dateSend", dateSend);
            comms.Parameters.AddWithValue("@message", message);
            comms.Parameters.AddWithValue("@userID", userID);
            comms.Parameters.AddWithValue("@isViewed", 0);
            comms.Parameters.AddWithValue("@link", link);
            int notificationID = Convert.ToInt32(comms.ExecuteScalar());
            Conn.Close();
            return notificationID;


            //string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
            //using (SqlConnection con = new SqlConnection(constr))
            //{
            //    using (SqlCommand cmd = new SqlCommand())
            //    {
            //        cmd.CommandText = "insert into notifications (dateSend, message, userID, isViewed, link) values (@dateSend, @message, @userID, @isViewed, @link)";
            //        con.Open();
            //        cmd.Connection = con;
            //        cmd.Parameters.AddWithValue("@dateSend", DateTime.Today);
            //        cmd.Parameters.AddWithValue("@message", message.Text);
            //        cmd.Parameters.AddWithValue("@isViewed", 0);
            //        cmd.Parameters.AddWithValue("@link", "");
            //        cmd.Parameters.AddWithValue("@userID", item.Value);
            //        cmd.ExecuteNonQuery();
            //        con.Close();
            //    }  
            //}
        }
    }

    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();


            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));


            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {

                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    public DataTable selectCompanyInfo(int userID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {               
            string selectinfo = "select_CompanyInfobyuserID";
            SqlCommand comms = new SqlCommand(selectinfo, Conn);
            comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@userID", userID);
            SqlDataAdapter da = new SqlDataAdapter(comms);
            DataTable info = new DataTable();
            da.Fill(info);
            //int companyID = info.Rows[0].Field<int>("companyID");
            Conn.Close();
            return info;
        }            
    }

    public DataTable selectPostingInfo(int companyID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string selectinfo = "select jobPostingID, companyID, title, description, duties, Qualifications, ContactEmail, dateDue, ContactPerson, department, other from posting";
            SqlCommand comms = new SqlCommand(selectinfo, Conn);
            //comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@companyID", companyID);
            SqlDataAdapter da = new SqlDataAdapter(comms);
            DataTable info = new DataTable();
            da.Fill(info);
            //int companyID = info.Rows[0].Field<int>("companyID");
            Conn.Close();
            return info;
        }
    }


    public DataTable selectstudentbyclassInfo (int classInfoID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            Conn.Open();
            string selectinfo = "select userID, studentID from student where classID = @classInfoID";
            SqlCommand comms = new SqlCommand(selectinfo, Conn);
            //comms.CommandType = System.Data.CommandType.StoredProcedure;
            comms.Parameters.AddWithValue("@classInfoID", classInfoID);
            SqlDataAdapter da = new SqlDataAdapter(comms);
            DataTable info = new DataTable();
            da.Fill(info);
            Conn.Close();
            return info;
        }
    }
    public void instrucorlist(ListBox lb)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select userID, fName, lName, email from genuser WHERE userType = 3";
                cmd.Connection = con;
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                lb.SelectionMode = ListSelectionMode.Multiple;
                while (rd.Read())
                {
                    ListItem item = new ListItem();
                    item.Text = rd["fName"].ToString() + " " + rd["lName"].ToString();
                    item.Value = rd["userID"].ToString();
                    lb.Items.Add(item);
                }
                con.Close();
                lb.Items.Insert(0, new ListItem("---select 1 or more(ctrl+) instructor(s)---", null));
            }
        }

    }


    public void instrucorlistemail(ListBox lb)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select userID, fName, lName, email from genuser WHERE userType = 3";
                cmd.Connection = con;
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                lb.SelectionMode = ListSelectionMode.Multiple;
                while (rd.Read())
                {
                    ListItem item = new ListItem();
                    item.Text = rd["fName"].ToString() + " " + rd["lName"].ToString();
                    item.Value = rd["email"].ToString();
                    lb.Items.Add(item);
                }
                con.Close();
                lb.Items.Insert(0, new ListItem("---select 1 or more(ctrl+) instructor(s)---", null));
            }
        }

    }
    public void studentlist(ListBox lb)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select userID, fName, lName, email from genuser WHERE userType = 2";
                cmd.Connection = con;
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                lb.SelectionMode = ListSelectionMode.Multiple;
                while (rd.Read())
                {
                    ListItem item = new ListItem();
                    item.Text = rd["fName"].ToString() + " " + rd["lName"].ToString();
                    item.Value = rd["userID"].ToString();
                    lb.Items.Add(item);
                }
                con.Close();
                lb.Items.Insert(0, new ListItem("---select 1 or more(ctrl+) student(s)----", null));
            }
        }
    }

    public void studentlistemail(ListBox lb)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select userID, fName, lName, email from genuser WHERE userType = 2";
                cmd.Connection = con;
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                lb.SelectionMode = ListSelectionMode.Multiple;
                while (rd.Read())
                {
                    ListItem item = new ListItem();
                    item.Text = rd["fName"].ToString() + " " + rd["lName"].ToString();
                    item.Value = rd["email"].ToString();
                    lb.Items.Add(item);
                }
                con.Close();
                lb.Items.Insert(0, new ListItem("---select 1 or more(ctrl+) student(s)----", null));
            }
        }
    }
    public int countMessage(int userID)
    {

        int count = 0;
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select * from notifications where userID =@userID";
                cmd.Parameters.AddWithValue("@userID", userID);
                cmd.Connection = con;
                con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {
                    if (rd["isViewed"].ToString().ToLower() == "false")
                    {
                        count++;
                    }
                }
            }
            con.Close();
        }
        return count;

        //using (SqlConnection conn = new SqlConnection(constr))
        //{
        //    conn.Open();
        //    string daString = "select * from notifications where userID =@userID";
        //    using (SqlDataAdapter da = new SqlDataAdapter())
        //    {
        //        SqlCommand command = new SqlCommand(daString, conn);
        //        command.Parameters.AddWithValue("@userID", Session["userID"]);
        //        da.SelectCommand = command;
        //        DataTable dTable = new DataTable();
        //        int count = dTable.Rows.Count;
        //        da.Fill(dTable);
        //        conn.Close();
        //        return count;
        //    }
        //}
    }

    public void bindgridviewwithposting(GridView gv, int companyID)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select jobPostingID, companyID, title, description, duties, Qualifications, ContactEmail, dateDue, ContactPerson, department, other from posting WHERE companyID = @companyID";
                cmd.Parameters.AddWithValue("@companyID", companyID);
                cmd.Connection = con;
                con.Open();
                gv.DataSource = cmd.ExecuteReader();
                gv.DataBind();
                con.Close();
            }
        } 
    }


    public void View1(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        //String connStr = "connection string";
        string connStr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;

        // add here extension that depends on your file type, you can change to any type.
        string fileName = Path.GetTempFileName() + ".doc";
        //string fileName = Path.GetTempFileName() +".pdf";
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT BinaryData FROM uploadfile WHERE ID = @ID";
                    cmd.Parameters.AddWithValue("@ID", id);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            int size = 1024 * 1024;
                            byte[] buffer = new byte[size];
                            int readBytes = 0;
                            int index = 0;
                            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                while ((readBytes = (int)dr.GetBytes(0, index, buffer, 0, size)) > 0)
                                {
                                    fs.Write(buffer, 0, readBytes);
                                    index += readBytes;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //ErrorMessage.Visible = true;
            //FailureText.Text += ex;
        }

        // open your file, the proper application will be executed because of proper file extension
        Process prc = new Process();
        prc.StartInfo.FileName = fileName;
        prc.Start();
    }



    public void updatingposingitem(string PostingID, string title, string description, string duties,
        string Qualifications,string ContactEmail,string ContactPerson,string department,string other)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {


            //FailureText.Text += "c1 value" + column1Value + " c2 value" + column2Value + "c5" + column5Value;
            int jobPostingID = Int32.Parse(PostingID);
            //bool and the aunto increm int have some 
            string updateuser = "Update posting SET title=@title, description=@description, duties=@duties, Qualifications=@Qualifications, ContactEmail=@ContactEmail, ContactPerson=@ContactPerson, department=@department, other=@other WHERE jobPostingID = @jobPostingID";
            SqlCommand comm3 = new SqlCommand(updateuser, Conn);
            comm3.Parameters.AddWithValue("@jobPostingID", jobPostingID);
            comm3.Parameters.AddWithValue("@title", title);
            comm3.Parameters.AddWithValue("@description", description);
            comm3.Parameters.AddWithValue("@duties", duties);
            comm3.Parameters.AddWithValue("@Qualifications", Qualifications);
            comm3.Parameters.AddWithValue("@ContactEmail", ContactEmail);
            comm3.Parameters.AddWithValue("@ContactPerson", ContactPerson);
            comm3.Parameters.AddWithValue("@department", department);
            comm3.Parameters.AddWithValue("@other", other);
            Conn.Open();
            comm3.ExecuteNonQuery();
            Conn.Close();

        }
    }


    public void bindgridviewwithapplication(GridView gv, int jobPostingID)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select a.jobPostingID, a.applicationResume, a.attachedCoverLetter, a.dateApplied, concat(g.fName , g.lName) as name, g.email from applications a inner join student s on a.userID = s.studentID inner join genuser g on s.userID = g.userID ORDER BY a.dateApplied";
                cmd.Parameters.AddWithValue("@jobPostingID", jobPostingID);
                cmd.Connection = con;
                con.Open();
                gv.DataSource = cmd.ExecuteReader();
                gv.DataBind();
                con.Close();
            }
        }
    }

    public DataTable selectnotificationsbyuser (int userID)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection conn = new SqlConnection(constr))
        {
            conn.Open();
            string daString = "select * from notifications where userID =@userID";
            using (SqlDataAdapter da = new SqlDataAdapter())
            {
                SqlCommand command = new SqlCommand(daString, conn);
                command.Parameters.AddWithValue("@userID", userID);
                da.SelectCommand = command;
                DataTable dTable = new DataTable();
                int count = dTable.Rows.Count;
                da.Fill(dTable);
                conn.Close();
                return dTable;
            }
        }
    }

    public void bindgridviewwithsinglecontent(GridView gv, int id)
    {
        string constr = ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
                cmd.CommandText = "select message from notifications where notificationID = @notificationID";
                cmd.Parameters.AddWithValue("@notificationID", id);
                cmd.Connection = con;
                con.Open();
                gv.DataSource = cmd.ExecuteReader();
                gv.DataBind();
                con.Close();
                //SuccessText.Text = "well done!";
                //SuccessMessage.Visible = true;

                //get the isViewed value which by notificationID.
                string sql2 = "SELECT isViewed FROM notifications WHERE notificationID = @notificationID";
                SqlCommand cmd2 = new SqlCommand(sql2, con);
                cmd2.Parameters.AddWithValue("@notificationID", id);
                con.Open();
                int viewedstatus = Convert.ToInt32(cmd2.ExecuteScalar());
                con.Close();
                //update isviewed
                if (viewedstatus == 0)
                {
                    string sql3 = "UPDATE notifications SET isViewed=1 WHERE notificationID = @notificationID";
                    SqlCommand cmd3 = new SqlCommand(sql3, con);
                    cmd3.Parameters.AddWithValue("@notificationID", id);
                    con.Open();
                    cmd3.ExecuteNonQuery();
                    con.Close();
                }

            }
        }
    }

    public int UserTypeCheck(string email)
    {
        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            string strSQL = "checkUserType";
            conn.Open();
            using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
            {
                compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                compCmd.Parameters.AddWithValue("@email", email);
                return (int)compCmd.ExecuteScalar();
            }
        }
    }
}