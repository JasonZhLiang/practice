﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class StudentApplyForPracticum : System.Web.UI.Page
{

    StudentBAL studentBA = new StudentBAL();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["email"] == null)
        {
            Response.Redirect("Account/Login.aspx");
        }
        else
        {


            if (!IsPostBack)
            {
                if (Session["user"] != null)
                {
                    int userID = Convert.ToInt32(Session["user"]);

                    GridView1.DataSource = studentBA.getPracticumPostings(userID);
                    GridView1.DataBind();




                    string storedProc = "fillResumeList";
                    string text = "docName";
                    string value = "ResumeID";
                    string stockMessage = "Select Resume";

                    try
                    {
                        studentBA.populateList(ddlResume, storedProc, text, value, stockMessage, userID);
                    }
                    catch (Exception ex)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
                    }
                }
                else { Label1.Text = "Please sign in."; }
                //>>>>>>> a77e244448c97f3d89a0b856d2e0667c62820f2e
            }
        }
    }

    protected void FillGridView_RowCommand(Object sender, GridViewCommandEventArgs e)
    {


        if (e.CommandName == "Print")
        {

            int index = Convert.ToInt32(e.CommandArgument);


            GridViewRow selectedRow = GridView1.Rows[index];

            String id = selectedRow.Cells[0].Text;
            int anID = Convert.ToInt32(id);

            int checkID = studentBA.checkFileID(anID);
            if (checkID != 0)
            {
                Display(anID);
            }
            else
            {
                Label1.Text = "File doesn't exist - Apply?";
            }
            



            // Label1.Text = "Print";



        }
        else if (e.CommandName == "Apply")
        {
            if (Session["user"] != null) { 
            ApplyID.Visible = true;

            int index = Convert.ToInt32(e.CommandArgument);


            GridViewRow selectedRow = GridView1.Rows[index];
            String job = selectedRow.Cells[1].Text;
            Label2.Text = job;
          
            String coverLetter = selectedRow.Cells[6].Text;

              int userID = Convert.ToInt32(Session["user"]);
            
            int resumeID = studentBA.checkResume(userID);
           
            Label1.Text = "";
            if (resumeID != 0) 
            { 
                chkResume.Visible = true;
            }
            if (coverLetter == "True") { flCoverLetter.Enabled = true; }
            else { flCoverLetter.Enabled = false; }
            btnApply.Enabled = true;

        }
            else { Label1.Text = "Please sign in."; }

        }
    }

    protected void Apply(object sender, EventArgs e)
    {

        int useID = 0;

        String use = Session["user"].ToString();
        useID = Convert.ToInt32(use);
        String jobTitle = "";
        String companyName = "";
        String userFName = "";
        String userLName = "";
       
        int jobID = Convert.ToInt32(Label2.Text);
        String[] jobArr = studentBA.JobTitleAndCompanyName(jobID);
        String[] fullName = studentBA.UserFullName(useID);
        if (jobArr[0] != null)
        {
            jobTitle = jobArr[0];
        }
        if (jobArr[1] != null)
        {
            companyName = jobArr[1];
        }
        if (fullName[0] != null)
        {
            userFName = fullName[0];
        }
        if (fullName[1] != null)
        {
            userLName = fullName[1];
        }
        String notiMessage = userFName + " " + userLName + " has applied for the " + companyName + " position: " + jobTitle + ".";
        String url = HttpContext.Current.Request.Url.AbsoluteUri;
        

        
        if ((chkResume.Visible == false) && (flCoverLetter.Enabled == true))
        {
            if ((flResume.HasFile) && (flCoverLetter.HasFile))
            {
                String resumeID = resumeUpload(useID);
                int resumeIDConvert = Convert.ToInt32(resumeID);
                String coverID = coverLetterUpload(useID);
                int CoverIDInt = Convert.ToInt32(coverID);

                if ((resumeID != "Error") && (coverID != "Error"))
                {
                    int resumeFileID = studentBA.uploadResumePullID(useID, resumeIDConvert);
                    int success = studentBA.insertApplicationCL(jobID, useID, resumeFileID, CoverIDInt);
                    int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                    Label1.Text = "Successfully applied.";
                    Response.Redirect(Request.RawUrl);
                }

            }
        }
            
            else if ((chkResume.Visible == false) && (flCoverLetter.Enabled == false))
            {
                if (flResume.HasFile)
                {
                    String resumeID = resumeUpload(useID);
                    int resumeIDConvert = Convert.ToInt32(resumeID);
                   


                    if (resumeID != "Error")
                    {
                        int resumeFileID = studentBA.uploadResumePullID(useID, resumeIDConvert);
                        int success = studentBA.insertApplicationNoCL(jobID, useID, resumeFileID);
                        int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                        Label1.Text = "Successfully applied.";
                        Response.Redirect(Request.RawUrl);
                    }

                }
            }
        else   if ((chkResume.Visible == true) && (flCoverLetter.Enabled == true) && (chkResume.Checked == false))
        {
            if ((flResume.HasFile) && (flCoverLetter.HasFile))
            {
                String resumeID = resumeUpload(useID);
                int resumeIDConvert = Convert.ToInt32(resumeID);
                String coverID = coverLetterUpload(useID);
                int CoverIDInt = Convert.ToInt32(coverID);

                if ((resumeID != "Error") && (coverID != "Error"))
                {
               
                    int resumeFileID = studentBA.uploadResumePullID(useID, resumeIDConvert);
                    int success = studentBA.insertApplicationCL(jobID, useID, resumeFileID, CoverIDInt);
                    int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                    Label1.Text = "Successfully applied.";
                    Response.Redirect(Request.RawUrl);
                }

            }
        }
        else if ((chkResume.Visible == true) && (flCoverLetter.Enabled == false) && (chkResume.Checked == false))
        {
            if (flResume.HasFile)
            {
                String resumeID = resumeUpload(useID);
                int resumeIDConvert = Convert.ToInt32(resumeID);
             
                if (resumeID != "Error")
                {
                
                    int resumeFileID = studentBA.uploadResumePullID(useID, resumeIDConvert);
                    int success = studentBA.insertApplicationNoCL(jobID, useID, resumeFileID);
                    int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                    Label1.Text = "Successfully applied.";
                    Response.Redirect(Request.RawUrl);
                }

            }
        }
        else if ((chkResume.Visible == true) && (flCoverLetter.Enabled == true) && (chkResume.Checked == true))
        {
            if (ddlResume.SelectedValue.ToString() != "0") { 
            if (flCoverLetter.HasFile)
            {
              
                String coverID = coverLetterUpload(useID);
                int CoverIDInt = Convert.ToInt32(coverID);
                int resID = Convert.ToInt32(ddlResume.SelectedValue);
                if (coverID != "Error")
                {
                  //  int resID = studentBA.getResumeID(useID);
                   
                    int success = studentBA.insertApplicationCL(jobID, useID, resID, CoverIDInt);
                    int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                    Label1.Text = "Successfully applied.";
                    Response.Redirect(Request.RawUrl);
                }

            }
        }
            else { Label1.Text = "Please choose a resume from the drop down."; }
        }
        else if ((chkResume.Visible == true) && (flCoverLetter.Enabled == false) && (chkResume.Checked == true))
        {
            if (ddlResume.SelectedValue.ToString() != "0")
            {
                int resID = Convert.ToInt32(ddlResume.SelectedValue);
                //int resID = studentBA.getResumeID(useID);

                int success = studentBA.insertApplicationNoCL(jobID, useID, resID);
                int insertNoti = studentBA.ApplyInsertNotification(notiMessage, useID, url);
                Label1.Text = "Successfully applied.";
                Response.Redirect(Request.RawUrl);

            }
            else { Label1.Text = "Please choose a resume from the drop down."; }
            }
        


            else { Label1.Text = "Please upload the correct amount of pdf files."; }

            btnApply.Enabled = false;

        
    }

    private void Display(int id)
    {
        Byte[] bytes = studentBA.displayStudentFile(id);

        Response.Buffer = true;
        Response.Charset = "";
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.ContentType = "application/pdf";
        Response.BinaryWrite(bytes);
        Response.Flush();
        Response.End();
    }
    protected void chkResume_CheckedChanged(object sender, EventArgs e)
    {
        if (chkResume.Checked == true)
        {
            flResume.Enabled = false;
        }
        else { flResume.Enabled = true; }
    }


    public String resumeUpload(int useID)
    {

        if (flResume.HasFile)
        {
            string filename = Path.GetFileName(flResume.PostedFile.FileName);
            string fileDocName = flResume.FileName;
            string contentType = flResume.PostedFile.ContentType;
            string date = DateTime.Today.ToString();
            int fileSize = flResume.PostedFile.ContentLength;
            //String strID = Session["user"].ToString();
            //    int id = Convert.ToInt32(strID);

            string fileExtension = Path.GetExtension(fileDocName);

            fileExtension = fileExtension.ToLower();

            if (fileExtension == ".pdf")
            {

                using (Stream fs = flResume.PostedFile.InputStream)
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        String fileID = studentBA.uploadFileDisplayID(fileExtension, filename, fileSize, date, bytes, useID);
                        return fileID;


                    }
                }
            }
            else
            {

                return "Error";
            }

        }
        else { return "Error"; }
    }

    public String coverLetterUpload(int useID)
    {

        if (flCoverLetter.HasFile)
        {
            string filename = Path.GetFileName(flCoverLetter.PostedFile.FileName);
            string fileDocName = flCoverLetter.FileName;
            string contentType = flCoverLetter.PostedFile.ContentType;
            string date = DateTime.Today.ToString();
            int fileSize = flCoverLetter.PostedFile.ContentLength;
            //String strID = Session["user"].ToString();
            //    int id = Convert.ToInt32(strID);

            string fileExtension = Path.GetExtension(fileDocName);

            fileExtension = fileExtension.ToLower();

            if (fileExtension == ".pdf")
            {

                using (Stream fs = flCoverLetter.PostedFile.InputStream)
                {
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        byte[] bytes = br.ReadBytes((Int32)fs.Length);
                        String coverID = studentBA.uploadFileDisplayID(fileExtension, filename, fileSize, date, bytes, useID);

                        return coverID;


                    }
                }
            }
            else
            {
                Label1.ForeColor = System.Drawing.Color.Red;

                return "Error";
            }

        }
        else { return "Error"; }

    }
}



