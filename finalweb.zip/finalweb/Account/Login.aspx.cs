﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using WebSiteForms;
using Owin;
using BusinessLogic;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Linq;
using System.Data;
using System.Security.Cryptography;
using System.Text;



public partial class Account_Login : Page
{
    InstructorBAL instructBAL = new InstructorBAL();
    protected void Page_Load(object sender, EventArgs e)
    {
      



    }

    public static class Encryptor
    {
        public static string MD5Hash(string text)
        {
            MD5 md5 = new MD5CryptoServiceProvider();

            
            md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

            
            byte[] result = md5.Hash;

            StringBuilder strBuilder = new StringBuilder();
            for (int i = 0; i < result.Length; i++)
            {
                
                strBuilder.Append(result[i].ToString("x2"));
            }
            return strBuilder.ToString();
        }

    }

    protected void LogIn(object sender, EventArgs e)
    {
        String email = UserName.Text;
        String password = Encryptor.MD5Hash(Password.Text);
        String fName = "Please";
        String lName = "Login";

        loginPartOne(email, password, fName, lName);
    }

    public void loginPartOne(String email, String password, String fName, String lName)
    {
        String userType = "0";
        String[] arr = instructBAL.loginPartOne(email, password, fName, lName);
        if (arr[0] != null) { userType = arr[0]; }
        if (arr[1] != null) { Session["user"] = arr[1]; }
        if (arr[2] != null) { Session["email"] = arr[2]; }
        if (arr[3] != null) { Session["fName"] = arr[3]; }
        if (arr[4] != null) { Session["lName"] = arr[4]; }

        if (Session["user"] != null)
        {
            String id = Session["user"].ToString();
            int success = instructBAL.loginUpdateDate(id);
        }

        if (userType == "1")
        {
            //Admin
            Response.Redirect("~/AddStudents.aspx");

        }
        else if (userType == "2")
        {
            //Student
            Response.Redirect("~/StudentApplyForPracticum.aspx");
        }
        else if (userType == "3")
        {
            //Faculty
            Response.Redirect("~/Instructor.aspx");

        }
        else if (userType == "4")
        {
            //Employer
            Response.Redirect("/companies/companyIndex.aspx");
        }
        else { lblFail.Text = "Failed to login, please try again."; }
    }


}