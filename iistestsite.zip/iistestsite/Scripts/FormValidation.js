﻿function validEmail(email)
{
    var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regEx.test(email);
}

function validateStudent()
{
    var eMail = document.getElementById("txtStudentEmail");
    var fname = document.getElementById("txtStudentFirstName");
    var lname = document.getElementById("txtStudentLastName");
    var stuID = document.getElementById("txtStudentID");
    var stuPhone = document.getElementById("txtStudentPhone");
    var stuPass = document.getElementById("txtStudentPassword");
    var stuConfirm = document.getElementById("txtStudentConfirm");

    var success = false;
    var errorMessage = "";
    var firstError = "";

}

function validateFaculty()
{
    var eMail = document.getElementById("txtFactEmail");
    var fname = document.getElementById("txtFacFirstName");
    var lname = document.getElementById("txtFacLastName");
    var role = document.getElementById("txtFacRole");
    var facPhone = document.getElementById("txtFacPhone");
    var facPass = document.getElementById("txtFacPassword");
    var facConfirm = document.getElementById("txtFacConfirm");

    var success = false;
    var errorMessage = "";
    var firstError = "";
}

function validateCompanyContact()
{
    var eMail = document.getElementById("txtCCtEmail");
    var fname = document.getElementById("txtCCtFirstName");
    var lname = document.getElementById("txtCCtLastName");
    var stuPhone = document.getElementById("txtCCtPhone");
    var stuPass = document.getElementById("txtCCtPassword");
    var stuConfirm = document.getElementById("txtCCtConfirm");
    var dept = document.getElementById("txtDepartment");

    var success = false;
    var errorMessage = "";
    var firstError = "";
}

function validateCompany()
{
    var eMail = document.getElementById("txtStudentEmail");
    var fname = document.getElementById("txtStudentFirstName");
    var lname = document.getElementById("txtStudentLastName");
    var stuPhone = document.getElementById("txtStudentPhone");
    var stuPass = document.getElementById("txtStudentPassword");
    var stuConfirm = document.getElementById("txtStudentConfirm");

    var success = false;
    var errorMessage = "";
    var firstError = "";
}