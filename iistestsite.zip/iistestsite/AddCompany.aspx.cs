﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BusinessLogic;

public partial class AddCompany : System.Web.UI.Page
{

    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }
            ClearFields(control.Controls);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            //clearing the list before preparing the connection 
            ddProvList.Items.Clear();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ToString());
            try
            {
                //pulling back the data from the DB to populate list
                string strSQL = "getProvinceList";
                SqlCommand comm = new SqlCommand(strSQL, conn);
                comm.CommandType = CommandType.StoredProcedure;

                conn.Open();

                SqlDataReader provReader = comm.ExecuteReader();

                while (provReader.Read())
                {
                    //populating the list and binding it to the dropdown
                    ListItem province = new ListItem();
                    province.Text = provReader["provinceName"].ToString();
                    province.Value = provReader["provinceID"].ToString();
                    ddProvList.Items.Add(province);

                }
                //binding the data and closing the reader
                ddProvList.DataBind();
                provReader.Close();
            }

            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
            }
            finally
            {
                //insert an initial empty value to the page and then close connection
                ddProvList.Items.Insert(0, new ListItem("Select Province", "0"));
                conn.Close();
            }
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        //call dynamic method to clear the page
        ClearFields(Page.Form.Controls);
    }
    protected void btnAddComp_Click(object sender, EventArgs e)
    {
        //to check for successful insert
        int returnVal;
        string success = "Company has been successfully added!";

        try
        {

        //pass all the values from the form to variables
        string phoneNum = txtCompanyPhone.Text;
        string companyName = txtCompanyName.Text;
        string streetAddress = txtStreetAddress.Text;
        string city = txtCity.Text;
        string postal = txtPostalCode.Text;
        string province = ddProvList.SelectedValue;

        //create a Admin business layer object to call method from that layer to GUI
        AdministratorBAL adminBA = new AdministratorBAL();
        returnVal = adminBA.AddCompany(phoneNum, companyName, streetAddress, city, postal, province);

        if (returnVal < 0)
        {
            //if return value is greater than 0 then send an alert for success and clear the form
            ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
            ClearFields(Page.Form.Controls);
        }

        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }
}