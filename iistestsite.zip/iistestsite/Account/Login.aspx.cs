﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using WebSiteForms;
using Owin;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Linq;
using System.Data;
//using WebSiteForms.Models;
//using WebSiteForms.Models;

public partial class Account_Login : Page
{
        protected void Page_Load(object sender, EventArgs e)
        {
         //   RegisterHyperLink.NavigateUrl = "Register";
          //  OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
       //     var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
        //    if (!String.IsNullOrEmpty(returnUrl))
          //  {
          //      RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
          //  }
        }

        protected void LogIn(object sender, EventArgs e)
        {
           

            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString);
                conn.Open();

                String loginEmail = UserName.Text;
                String loginPassword = Password.Text;
                String userType = "0";

                SqlCommand loginCommand = new SqlCommand();
                loginCommand.CommandText = "pullLoginInfo";
                loginCommand.CommandType = CommandType.StoredProcedure;
                loginCommand.Connection = conn;
                loginCommand.Parameters.AddWithValue("@email", UserName.Text);
                loginCommand.Parameters.AddWithValue("@password", Password.Text);
                SqlDataReader reader;

                reader = loginCommand.ExecuteReader();

                while (reader.Read())
                {
                    if ((reader["email"].ToString() == loginEmail) && (reader["userPassword"].ToString() == loginPassword))
                    {

                        Session["user"] = reader["userID"].ToString();
                        Session["email"] = reader["email"].ToString();
                        userType = reader["userType"].ToString();

                    }
                   


                }
                reader.Close();

                if (Session["user"] != null)
                {
                    SqlCommand SqlUpdateDate = new SqlCommand();
                    SqlUpdateDate.CommandText = "updateLastSignedIn";
                    SqlUpdateDate.CommandType = CommandType.StoredProcedure;
                    SqlUpdateDate.Connection = conn;
                    SqlUpdateDate.Parameters.AddWithValue("@userID", Session["user"]);

                    SqlDataReader reader1 = SqlUpdateDate.ExecuteReader();
                    reader1.Close();
                }

                conn.Close();


                //1 = Admin
                //2 = Student
                //3 = Faculty
                //4 = Employer



                if (userType == "1")
                {
                    //Admin
                    Response.Redirect("~/AddStudents.aspx");
                    
                }
                else if (userType == "2")
                {
                    //Student

                }
                else if (userType == "3")
                {
                    //Faculty
                    Response.Redirect("~/Instructor.aspx");

                }
                else if (userType == "4")
                {
                    //Employer

                }
                else { lblFail.Text = "Failed to login, try again"; }


            }
            catch (SqlException f)
            {


            }


        }
}