﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BusinessLogic;


public partial class AddStudents : System.Web.UI.Page
{
    //method to loop through each control on the page
    //and clear the control
    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }

            ClearFields(control.Controls);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            //clearing the list before preparing the connection 
            ddClassInfoList.Items.Clear();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ToString());
            try
            {
                //pulling back the data from the DB to populate list
                string strSQL = "getClassInformation";
                SqlCommand comm = new SqlCommand(strSQL, conn);
                comm.CommandType = CommandType.StoredProcedure;

                conn.Open();

                SqlDataReader classReader = comm.ExecuteReader();

                while (classReader.Read())
                {
                    //populating the list and binding it to the dropdown
                    var classInfo = new ListItem();
                    classInfo.Text = classReader["classinformation"].ToString();
                    classInfo.Value = classReader["classInfoID"].ToString();
                    ddClassInfoList.Items.Add(classInfo);

                }
                //binding the data and closing the reader
                ddClassInfoList.DataBind();
                classReader.Close();
            }

            catch (Exception ex)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
            }
            finally
            {
                //insert an initial empty value to the page and then close connection
                ddClassInfoList.Items.Insert(0, new ListItem("Select Class Info", "0"));
                conn.Close();
            }
        }
    }

    protected void btnStuReset_Click(object sender, EventArgs e)
    {
        //call method to clear the page
        ClearFields(Page.Form.Controls);
    }

    protected void btnAddStudent_Click(object sender, EventArgs e)
    {
        //variable for password error
        string errMessage = "Passwords do not match, please enter matching information.";
        //variables for success scenario
        int returnVal;
        string success = "Student successfully added!";
        //hardcoding this value because this page is only to add students specifically
        int userType = 2;

        try
        {
            string email = txtStuEmail.Text;
            string password = txtPassword.Text;
            string confirm = txtConfirm.Text;
            string fname = txtStuFname.Text;
            string lname = txtStuLname.Text;
            int studentID = Convert.ToInt32(txtStuID.Text);
            string phone = txtStuPhone.Text;
            int classInfo = Convert.ToInt32(ddClassInfoList.SelectedValue);
            string profile = txtLIprofile.Text;

            if (password != confirm)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "passwordAlert", "alert('" + errMessage + "');", true);
            }
            else 
            {
                AdministratorBAL adminBA = new AdministratorBAL();
                returnVal = adminBA.AddStudent(fname,lname,userType,password,email,studentID,phone,classInfo,profile);

                if (returnVal < 0)
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "successAlert", "alert('" + success + "');", true);
                    ClearFields(Page.Form.Controls);
                }
            }

        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('" + ex + "');", true);
        }
    }
}