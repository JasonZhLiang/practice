﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Linq;
using System.Data;

public partial class Instructor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void SearchStudent(object sender, EventArgs e)
    {
       
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString);
            DataTable dt = new DataTable();
            SqlCommand loginCommand = new SqlCommand();
            loginCommand.CommandText = "getMoreStudentInfo";
            loginCommand.CommandType = CommandType.StoredProcedure;
            loginCommand.Connection = conn;
            loginCommand.Parameters.AddWithValue("@stuID", stuID.Text);

            SqlDataAdapter sda = new SqlDataAdapter(loginCommand);


            try
            {
                conn.Open();
                sda.Fill(dt);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
            }

            GridView2.DataSource = dt;
            GridView2.DataBind();






       
    }

}