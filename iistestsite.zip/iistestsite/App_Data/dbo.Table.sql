﻿CREATE TABLE [dbo].[Table]
(
	[ID] BIGINT NOT NULL PRIMARY KEY, 
    [FileName] VARCHAR(50) NULL, 
    [DateTimeUploaded] DATETIME NULL, 
    [MIME] VARCHAR(50) NULL, 
    [BinaryData] VARBINARY(MAX) NULL
)
