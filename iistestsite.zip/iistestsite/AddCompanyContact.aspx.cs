﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class AddCompanyContact : System.Web.UI.Page
{

    public static void ClearFields(ControlCollection pageControls)
    {
        foreach (Control control in pageControls)
        {
            string strContName = (control.GetType()).Name;

            switch (strContName)
            {
                case "TextBox":
                    TextBox tbSource = (TextBox)control;
                    tbSource.Text = "";
                    break;
                case "RadioButtonList":
                    RadioButtonList rblSource = (RadioButtonList)control;
                    rblSource.SelectedIndex = -1;
                    break;
                case "DropDownList":
                    DropDownList ddlSource = (DropDownList)control;
                    ddlSource.SelectedIndex = -1;
                    break;
                case "ListBox":
                    ListBox lbsource = (ListBox)control;
                    lbsource.SelectedIndex = -1;
                    break;
            }
            ClearFields(control.Controls);
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
       if (!Page.IsPostBack)
        {

            //clearing the list before preparing the connection 
            ddCompList.Items.Clear();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ToString());
            try
            {
                //pulling back the data from the DB to populate list
                string strSQL = "getCompanyList";
                SqlCommand comm = new SqlCommand(strSQL, conn);
                comm.CommandType = CommandType.StoredProcedure;

                conn.Open();

                SqlDataReader provReader = comm.ExecuteReader();

                while (provReader.Read())
                {
                    //populating the list and binding it to the dropdown
                    var company = new ListItem();
                    company.Text = provReader["companyName"].ToString();
                    company.Value = provReader["companyID"].ToString();
                    ddCompList.Items.Add(company);

                }
                //binding the data and closing the reader
                ddCompList.DataBind();
                provReader.Close();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //insert an initial empty value to the page and then close connection
                ddCompList.Items.Insert(0, new ListItem("Select Company", "0"));
                conn.Close();
            }
        }
    }

    protected void btnAddCct_Click(object sender, EventArgs e)
    {

    }
    protected void btnReset_Click(object sender, EventArgs e)
    {

    }
}