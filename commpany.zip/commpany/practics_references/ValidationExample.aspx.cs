﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ValidationExample : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        labelMessage.Text = "";
    }
    protected void buttonSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            labelMessage.Text = "Your reservation has been processed.";
        }
        else
        {
            labelMessage.Text = "Page is not valid.";
        }
    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            DateTime.ParseExact(args.Value, "m/d/yyyy",
                System.Globalization.DateTimeFormatInfo.InvariantInfo);
            args.IsValid = true;
        }
        catch
        {
            args.IsValid = false;
        }
    }
    protected void checkPhoneConfirmation_CheckedChanged(object sender, EventArgs e)
    {
        if (checkPhoneConfirmation.Checked)
        {
            textPhoneNumber.Enabled = true;
            validatorRequiredPhoneNumber.ValidationGroup ="AllValidators";
            validatorRegExPhoneNumber.ValidationGroup = "AllValidators";
        }
        else
        {
            textPhoneNumber.Enabled = false;
            validatorRequiredPhoneNumber.ValidationGroup = "";
            validatorRegExPhoneNumber.ValidationGroup = "";

        }
    }
}