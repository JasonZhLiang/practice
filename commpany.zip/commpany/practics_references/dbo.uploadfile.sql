﻿CREATE TABLE [dbo].[uploadfile] (
    [ID]               BIGINT          IDENTITY (1, 1) NOT NULL,
    [FileName]         VARCHAR (50)    NULL,
    [DateTimeUploaded] DATETIME        NULL,
    [MIME]             VARCHAR (MAX)   NULL,
    [BinaryData]       VARBINARY (MAX) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

