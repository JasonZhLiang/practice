﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class registerpageexampleLogin2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string queryFetch = "select password, activated from Users2 where email ='"+txtEmail.Text+"'";
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand(queryFetch, con);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        int no = dt.Rows.Count;
        if (no > 0)
        {
            if (dt.Rows[0][0].ToString() == txtPassword.Text)//dt.row[0][0] means password,[1]activated
            {
                if(dt.Rows[0][1].ToString() == "True")
                {
                    Response.Redirect("Default.aspx");//redirect to home page
                }
                else
                {
                    Response.Write("account not activated");
                }
            }
            else
            {
                Response.Write("password not match");
            }
        }
        else
        {
            Response.Write("sing in to your account");
        } 
    }
}