﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;

public partial class registerpageexample_2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        saveToDB();
    }

    public void saveToDB()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
        con.Open();
        string cmdText = "Insert Into Users2 (name ,email ,password) values('" + txtName.Text + "','" + txtEmail + "','" + txtPassword +"')";
        SqlCommand cmd = new SqlCommand(cmdText, con);
        int no = cmd.ExecuteNonQuery();
        if (no > 0)
        {
            sendEmail();
            Response.Write("registered succsessfully");
        }
        else
        {
            Response.Write("sorry unable to register");
        }
    }

    public void sendEmail()
    {
        MailMessage messege = new MailMessage();
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        //be sure to change the underneath link to correct url
        string useractivation = "http://nbcc.trip/useractivation.aspx?email=" + txtEmail.Text;
        messege.From = new MailAddress("nbcc.trip@gmail.com");
        messege.To.Add(txtEmail.Text);
        messege.Subject = "nbcc trip Account Activation";
        messege.Body = "Hi " + txtName.Text + ", <br />your email confirmation link is here <br /> <a href= '" + useractivation+"'> Click here! </a>";
        messege.IsBodyHtml = true;
        client.EnableSsl = true;
        client.UseDefaultCredentials = true;
        client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
        client.Send(messege);
    }
}