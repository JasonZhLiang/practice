﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class useractivation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            if (Request.QueryString.Keys[0] == "email")
            {
                string email = Request.QueryString["email"].ToString();
                //Response.Write(email+" display email value ");
                string queryactivate = "Update users2 set activated = 'true' where email = '" + email + "'";
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand(queryactivate, con);
                int no = cmd.ExecuteNonQuery();
                if (no > 0)
                {
                    Response.Write("account activated succsessfully");
                }
                else
                {
                    Response.Write("sorry unable to activate your account");
                }            
            }
        }
    }

}