﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataAccessLayer
{
    public class NavbarDAL
    {
        // USERTYPE CHECK FOR NAVBAR PERMISSIONS
        public int UserTypeCheck(string email)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //sql to call the stored procedure
                    string strSQL = "checkUserType";

                    //open the connection
                    conn.Open();

                    //using the stored procedure
                    using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@email", email);

                        return (int)compCmd.ExecuteScalar();
                    }

                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }
    }
}
