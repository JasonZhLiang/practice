﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace DataAccessLayer
{
    //did not create objects for insertion as it seemed
    //unnecessary to create an object jsut to insert it into
    //the database

    public class AdministratorDAL
    {
        //method to update user accounts from the administrator page
        public int UpdateAccount(int id, string email, string fname, string lname, string password, int status)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionSTring"].ConnectionString))
            {
                try
                {
                    string updateProc = "updateUserInformation";
                    conn.Open();
                    using (SqlCommand updateCmd = new SqlCommand(updateProc, conn))
                    {
                        updateCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        updateCmd.Parameters.AddWithValue("@userID",id);
                        updateCmd.Parameters.AddWithValue("@email", email);
                        updateCmd.Parameters.AddWithValue("@fname", fname);
                        updateCmd.Parameters.AddWithValue("@lname", lname);
                        updateCmd.Parameters.AddWithValue("@password", password);
                        updateCmd.Parameters.AddWithValue("@activity", status);

                        int result = updateCmd.ExecuteNonQuery();
                        return result;

                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                finally
                {
                    conn.Close();
                }
            }
        }


        //method to populate the gridview to update/disable user accounts
        public DataTable GetUserAccounts()
        {
            DataTable userTable = new DataTable();
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionSTring"].ConnectionString))
            {
                try
                {
                    string storedProcedure = "selectUserInfoForUpdates";

                    conn.Open();

                    using (SqlCommand usersCmd = new SqlCommand(storedProcedure, conn))
                    {
                        usersCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        SqlDataReader userReader = usersCmd.ExecuteReader();

                        if (userReader.HasRows)
                        {
                            userTable.Load(userReader);
                        }
                        return userTable;
                    }
                }

                catch (Exception e)
                {
                    throw e;
                }
                finally
                {
                    conn.Close();
                }
            }
        }
        //this method is in place to help check if faculty member exists 
        //in database and help to prevent insertion of duplicate records
        public int CheckForFaculty(string email)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //sql to call the stored procedure
                    string strSQL = "checkForFaculty";

                    //open the connection
                    conn.Open();

                    //using the stored procedure
                    using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@email", email);
                        SqlDataReader reader = compCmd.ExecuteReader();

                        //if there is a result
                        if (reader.HasRows)
                        {
                            //then return true
                            return 1;
                        }
                        else
                        {
                            //else return false
                            return 0;
                        }
                    }

                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }

        //method to add faculty members to database
        public int AddFacultyToDB(string fname, string lname, int userType, string password, string email, string telephoneNum, int campusID, int roleID, string startDate, string endDate)
        {
            //uses the SQL connection stored in the web config file
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //SQL statement to insert into DB
                    string sql = "insertFacultyMember";

                    //open the DB
                    conn.Open();

                    //create the command and pass values to the parameters
                    //then execute the query
                    using (SqlCommand compCmd = new SqlCommand(sql, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@fname", fname);
                        compCmd.Parameters.AddWithValue("@lname", lname);
                        compCmd.Parameters.AddWithValue("@userType", userType);
                        compCmd.Parameters.AddWithValue("@passwd", password);
                        compCmd.Parameters.AddWithValue("@email", email);
                        compCmd.Parameters.AddWithValue("@telephoneNum", telephoneNum);
                        compCmd.Parameters.AddWithValue("@campusID", campusID);
                        compCmd.Parameters.AddWithValue("@roleID", roleID);
                        compCmd.Parameters.AddWithValue("@startDate", startDate);
                        compCmd.Parameters.AddWithValue("@endDate", endDate);
                        int recordsAffected = compCmd.ExecuteNonQuery();
                        return recordsAffected;
                    }
                }
                catch (SqlException e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }
        //method to populate drop down list 
        public void populateDropDownList(DropDownList list, string StoredProc, string text, string val, string stockMessage)
        {
            //clearing the list before preparing the connection 
            list.Items.Clear();
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ToString());
            try
            {
                //pulling back the data from the DB to populate list
                SqlCommand comm = new SqlCommand(StoredProc, conn);
                comm.CommandType = System.Data.CommandType.StoredProcedure;

                conn.Open();

                SqlDataReader reader = comm.ExecuteReader();

                while (reader.Read())
                {
                    //populating the list and binding it to the dropdown
                    ListItem item = new ListItem();
                    item.Text = reader[text].ToString();
                    item.Value = reader[val].ToString();
                    list.Items.Add(item);

                }
                //binding the data and closing the reader
                list.DataBind();
                reader.Close();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                //insert an initial empty value to the page and then close connection
                list.Items.Insert(0, new ListItem(stockMessage, "0"));
                conn.Close();
            }
        }

        //this method is in place to help check if company contact exists 
        //in database and help to prevent insertion of duplicate records
        public int CheckForCompanyContact(string email, int companyID)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //sql to call the stored procedure
                    string strSQL = "checkForCompanyContact";

                    //open the connection
                    conn.Open();

                    //using the stored procedure
                    using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@email", email);
                        compCmd.Parameters.AddWithValue("@companyID", companyID);
                        SqlDataReader reader = compCmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            //then return true
                            return 1;
                        }
                        else
                        {
                            //else return false
                            return 0;
                        }
                    }

                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }


        //this method is in place as a means to prevent duplicate entry 
        //into the database the stored procedure performs a count on the company name

        public int CheckForCompany(string companyName)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //sql to call the stored procedure
                    string strSQL = "checkForCompany";

                    //open the connection
                    conn.Open();

                    //using the stored procedure
                    using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@companyName", companyName);
                        SqlDataReader reader = compCmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            //then return true
                            return 1;
                        }
                        else
                        {
                            //else return false
                            return 0;
                        }
                    }

                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }


        //this method is in place to count students in the DB
        //based on their studentID, method will aid in preventing
        //duplicate records being entered
        public int CheckForStudent(int studentID)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //sql to call the stored procedure
                    string strSQL = "checkForStudent";

                    //open the connection
                    conn.Open();

                    //using the stored procedure
                    using (SqlCommand stuCmd = new SqlCommand(strSQL, conn))
                    {
                        stuCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        stuCmd.Parameters.AddWithValue("@studentID", studentID);

                        SqlDataReader reader = stuCmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            //then return true
                            return 1;
                        }
                        else
                        {
                            //else return false
                            return 0;
                        }
                    }

                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }

        public int AddCompanyToDataBase(string phoneNum, string compName, string streetAdd, string city, string postal, string province)
        {
            //uses the SQL connection stored in the web config file
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //SQL statement to insert into DB
                    string sql = "insertCompany";

                    //open the DB
                    conn.Open();

                    //create the command and pass values to the parameters
                    //then execute the query
                    using (SqlCommand compCmd = new SqlCommand(sql, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@telephoneNum", phoneNum);
                        compCmd.Parameters.AddWithValue("@companyName", compName);
                        compCmd.Parameters.AddWithValue("@streetAddress", streetAdd);
                        compCmd.Parameters.AddWithValue("@city", city);
                        compCmd.Parameters.AddWithValue("@postal", postal);
                        compCmd.Parameters.AddWithValue("@province", province);
                        int recordsAffected = compCmd.ExecuteNonQuery();
                        return recordsAffected;
                    }
                }
                catch (SqlException e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }

        //method to insert a student 
        public int AddStudentUser(string first, string last, int uType, string password, string email, int studentID, string phoneNum, int classID, string profile)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //SQL statement to insert into DB
                    string sql = "insertStudent";

                    //open the DB
                    conn.Open();

                    //create the command and pass values to the parameters
                    //then execute the query
                    using (SqlCommand compCmd = new SqlCommand(sql, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@fname", first);
                        compCmd.Parameters.AddWithValue("@lname", last);
                        compCmd.Parameters.AddWithValue("@userType", uType);
                        compCmd.Parameters.AddWithValue("@passwd", password);
                        compCmd.Parameters.AddWithValue("@email", email);
                        compCmd.Parameters.AddWithValue("@stuID", studentID);
                        compCmd.Parameters.AddWithValue("@telephoneNum", phoneNum);
                        compCmd.Parameters.AddWithValue("@classID", classID);
                        compCmd.Parameters.AddWithValue("@linkedIn", profile);
                        int recordsAffected = compCmd.ExecuteNonQuery();
                        return recordsAffected;
                    }
                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }

        //method to insert a company contact
        public int AddCompanyContact(string fname, string lname, int userType, string password, string email, int companyID, string telephoneNum, string department)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
            {
                try
                {
                    //SQL statement to insert into DB
                    string sql = "insertCompanyContact";

                    //open the DB
                    conn.Open();

                    //create the command and pass values to the parameters
                    //then execute the query
                    using (SqlCommand compCmd = new SqlCommand(sql, conn))
                    {
                        compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                        compCmd.Parameters.AddWithValue("@fname", fname);
                        compCmd.Parameters.AddWithValue("@lname", lname);
                        compCmd.Parameters.AddWithValue("@userType", userType);
                        compCmd.Parameters.AddWithValue("@passwd", password);
                        compCmd.Parameters.AddWithValue("@email", email);
                        compCmd.Parameters.AddWithValue("@companyID", companyID);
                        compCmd.Parameters.AddWithValue("@telephoneNum", telephoneNum);
                        compCmd.Parameters.AddWithValue("@dept", department);
                        int recordsAffected = compCmd.ExecuteNonQuery();
                        return recordsAffected;
                    }
                }
                catch (Exception e)
                {
                    //throw the exception
                    throw e;
                }
                finally
                {
                    //close the connection
                    conn.Close();
                }
            }
        }
    }
}
