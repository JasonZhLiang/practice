﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for companyDA
/// </summary>
public class companyDA
{
	public companyDA()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    public static void jobpostingattachfile(string MIME, string FileName, 
        decimal Size, DateTime DateTimeUploaded, byte[] BinaryData, int userID)
    {
        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            const string SQL = "INSERT INTO [uploadedfile] ([docType], [docName], [docSize], [dateUploaded], [actualFile],[userID]) VALUES (@MIME, @FileName, @Size, @DateTimeUploaded, @BinaryData,@userID)";
            SqlCommand cmd = new SqlCommand(SQL, Conn);
            cmd.Parameters.AddWithValue("@MIME", MIME);
            cmd.Parameters.AddWithValue("@FileName", FileName);
            cmd.Parameters.AddWithValue("@Size", Size);
            cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTimeUploaded);
            cmd.Parameters.AddWithValue("@BinaryData", BinaryData);
            cmd.Parameters.AddWithValue("@userID", userID);

            Conn.Open();
            cmd.ExecuteNonQuery();
        }
    }
}