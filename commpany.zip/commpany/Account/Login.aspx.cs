﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using System;
using System.Web;
using System.Web.UI;
using TripCweb;



using Owin;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml.Linq;
using System.Linq;
using System.Data;
using System.Security.Cryptography;
using System.Text;


public partial class Account_Login : Page
{
        protected void Page_Load(object sender, EventArgs e)
        {
            //comment those for link to our project purpose
            //RegisterHyperLink.NavigateUrl = "Register";
            //OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
            //var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            //if (!String.IsNullOrEmpty(returnUrl))
            //{
            //    RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            //}
        }

        protected void LogIn(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user password
                var manager = new UserManager();
                ApplicationUser user = manager.Find(UserName.Text, Password.Text);
                if (user != null)
                {
                    IdentityHelper.SignIn(manager, user, RememberMe.Checked);
                    IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                }
                else
                {
                    FailureText.Text = "Invalid username or password.";
                    ErrorMessage.Visible = true;
                }
            }
        }

        public static class Encryptor
        {
            public static string MD5Hash(string text)
            {
                MD5 md5 = new MD5CryptoServiceProvider();

                //compute  hash from the bytes of text
                md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));

                //get hash result after compute it
                byte[] result = md5.Hash;

                StringBuilder strBuilder = new StringBuilder();
                for (int i = 0; i < result.Length; i++)
                {
                    //change it into to hexadecimal digits for each byte
                    strBuilder.Append(result[i].ToString("x2"));
                }
                return strBuilder.ToString();
            }

        }

        protected void LogIn1(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString);
                conn.Open();
                String loginEmail = UserName.Text;
                String loginPassword = Password.Text;
                //String loginPassword = Encryptor.MD5Hash(logPassword);
                String userType = "0";
                SqlCommand loginCommand = new SqlCommand();
                loginCommand.CommandText = "pullLoginInfo";
                loginCommand.CommandType = CommandType.StoredProcedure;
                loginCommand.Connection = conn;
                loginCommand.Parameters.AddWithValue("@email", UserName.Text);
                loginCommand.Parameters.AddWithValue("@password", Password.Text);
                //loginCommand.Parameters.AddWithValue("@password", Encryptor.MD5Hash(Password.Text));
                SqlDataReader reader;
                reader = loginCommand.ExecuteReader();
                while (reader.Read())
                {
                    //if ((reader["email"].ToString() == loginEmail) && (reader["userPassword"].ToString() == Encryptor.MD5Hash(loginPassword)))
                    if ((reader["email"].ToString() == loginEmail) && (reader["userPassword"].ToString() == loginPassword))
                    {
                        Session["userID"] = reader["userID"].ToString();
                        Session["email"] = reader["email"].ToString();
                        userType = reader["userType"].ToString();
                    }
                }
                reader.Close();
                if (Session["user"] != null)
                {
                    SqlCommand SqlUpdateDate = new SqlCommand();
                    SqlUpdateDate.CommandText = "updateLastSignedIn";
                    SqlUpdateDate.CommandType = CommandType.StoredProcedure;
                    SqlUpdateDate.Connection = conn;
                    SqlUpdateDate.Parameters.AddWithValue("@userID", Session["user"]);

                    SqlDataReader reader1 = SqlUpdateDate.ExecuteReader();
                    reader1.Close();
                }
                conn.Close();
                //1 = Admin
                //2 = Student
                //3 = Faculty
                //4 = Employer
                if (userType == "1")
                {
                    //Admin
                    Response.Write("<script>alert('test test');</script>");
                    Response.Redirect("~/Default.aspx");
                }
                else if (userType == "2")
                {
                    //Student

                }
                else if (userType == "3")
                {
                    //Faculty
                    Response.Redirect("~/Instructor.aspx");

                }
                else if (userType == "4")
                {
                    Response.Write("<script>alert('Hello welcome to company management Page');</script>");
                    Response.Write("<script>alert('test test');</script>");

                    Response.Redirect("/companies/companyIndex.aspx?user="+(string)Session["user"]);                    
                }
                else
                { 
                    FailureText.Text = "Failed to login, please try again.";
                    ErrorMessage.Visible = true;
                }
            }
            catch (SqlException f)
            {

            }
        }
        
}