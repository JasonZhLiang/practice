﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class GenericUser
    {
        private string firstname;
        private string lastname;
        private int userType;
        private string password;
        private string email;
        private int isActive;
        private string lastSignedIn;

        public GenericUser()
        {

        }

        public GenericUser(string email, string firstname, string lastname, int userType, string password, string lastSignedIn, int isActive)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.UserType = userType;
            this.Password = password;
            this.Email = email;
            this.IsActive = isActive;
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public int UserType
        {
            get { return userType; }
            set { userType = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public int IsActive
        {
            get { return isActive; }
            set { isActive = value; }
        }

        public string LastSignedIn
        {
            get { return lastSignedIn; }
            set { lastSignedIn = value; }
        }
    }
}
