﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
   public class Campus
    {
        private int campusID;
        private string phoneNumber;

        public Campus() { }

        public Campus(int campusID, string phoneNumber)
        {
            this.CampusID = campusID;
            this.PhoneNumber = phoneNumber;
        }

        public int CampusID
        {
            get { return campusID; }
            set { campusID = value; }
        }


        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }
    }
}
