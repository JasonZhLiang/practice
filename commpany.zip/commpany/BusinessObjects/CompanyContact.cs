﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
     public class CompanyContact
    {
        private string firstname;
        private string lastname;
        private int userType;
        private string password;
        private string email;
        private int companyID;
        private string telephoneNumber;
        private string department;

        public CompanyContact()
        {

        }
        public CompanyContact(string firstname, string lastname, int userType, string password, string email, string telephoneNumber, int companyID, string department)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.UserType = userType;
            this.Password = password;
            this.Email = email;
            this.TelephoneNumber = telephoneNumber;
            this.CompanyID = companyID;
            this.Department = department;

        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public int UserType
        {
            get { return userType; }
            set { userType = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string TelephoneNumber
        {
            get { return telephoneNumber; }
            set { telephoneNumber = value; }
        }

        public int CompanyID
        {
            get { return companyID; }
            set { companyID = value; }
        }

        public string Department
        {
            get { return department; }
            set { department = value; }
        }
    }
}
