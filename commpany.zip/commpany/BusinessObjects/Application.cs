﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class Application
    {
        private int jobPostingID;
        private int studentID;
        private int applicationResume;
        private DateTime dateApplied;

        public Application()
        {

        }

        public Application(int jobPostingID, int studentID, int applicationResume, DateTime dateApplied)
        {
            this.JobPostingID = jobPostingID;
            this.StudentID = studentID;
            this.ApplicationResume = applicationResume;
            this.DateApplied = dateApplied;
        }

        public int JobPostingID
        {
            get { return jobPostingID; }
            set { jobPostingID = value; }
        }

        public int StudentID
        {
            get { return studentID; }
            set { studentID = value; }
        }

        public int ApplicationResume
        {
            get { return applicationResume; }
            set { applicationResume = value; }
        }

        public DateTime DateApplied
        {
            get { return dateApplied; }
            set { dateApplied = value; }
        }
    }
}
