﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
   public class Company
    {
        private int companyID;

        public int CompanyID
        {
            get { return companyID; }
            set { companyID = value; }
        }
        private string telephoneNum;

        public string TelephoneNum
        {
            get { return telephoneNum; }
            set { telephoneNum = value; }
        }
        private string companyName;

        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }
        private string streetAddress;

        public string StreetAddress
        {
            get { return streetAddress; }
            set { streetAddress = value; }
        }
        private string city;

        public string City
        {
            get { return city; }
            set { city = value; }
        }
        private string postal;

        public string Postal
        {
            get { return postal; }
            set { postal = value; }
        }
        private string province;

        public string Province
        {
            get { return province; }
            set { province = value; }
        }
        public Company() { }
        public Company(int companyID, string telephoneNum, string companyName,
            string streetAddress, string city, string postal, string province)
        {
            this.CompanyID = companyID;
            this.TelephoneNum = telephoneNum;
            this.CompanyName = companyName;
            this.StreetAddress = streetAddress;
            this.City = city;
            this.Postal = postal;
            this.Province = province;

        }
    }
}
