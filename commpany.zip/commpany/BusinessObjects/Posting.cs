﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class Posting
    {
        int jobPostingID;

        public int JobPostingID
        {
            get { return jobPostingID; }
            set { jobPostingID = value; }
        }
        int companyID;

        public int CompanyID
        {
            get { return companyID; }
            set { companyID = value; }
        }
        string title;

        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        string description;

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        DateTime datePosting;

        public DateTime DatePosting
        {
            get { return datePosting; }
            set { datePosting = value; }
        }
        int attachedFileID;

        public int AttachedFileID
        {
            get { return attachedFileID; }
            set { attachedFileID = value; }
        }
        string status;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public Posting() { }
        public Posting(int jobPostingID, int companyID, string title, string description
            , string duties, string other, DateTime datePosting, int attachedFileID, string status)
        {
            this.JobPostingID = jobPostingID;
            this.CompanyID = companyID;
            this.Title = title;
            this.Description = description;
            this.DatePosting = datePosting;
            this.AttachedFileID = attachedFileID;
            this.Status = status;
        }
    }
}
