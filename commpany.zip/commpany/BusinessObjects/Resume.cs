﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class Resume
    {
        private int resumeID;

        public int ResumeID
        {
            get { return resumeID; }
            set { resumeID = value; }
        }
        private int studentID;

        public int StudentID
        {
            get { return studentID; }
            set { studentID = value; }
        }
        private int attachedFileID;

        public int AttachedFileID
        {
            get { return attachedFileID; }
            set { attachedFileID = value; }
        }

        public Resume() { }

        public Resume(int resumeID, int studentID, int attachedFildID)
        {
            this.ResumeID = resumeID;
            this.StudentID = StudentID;
            this.AttachedFileID = attachedFileID;
        }
    }
}
