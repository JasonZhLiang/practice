﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class Faculty 
    {
        private string firstname;
        private string lastname;
        private int userType;
        private string password;
        private string email;
        private string telephoneNumber;
        private int campusID;
        private int roleID;
        private string startDate;
        private string endDate;

        public Faculty()
        {

        }

        public Faculty(string firstname, string lastname, int userType, string password, string email, string telephoneNumber, int campusID, int roleID, string startDate, string endDate)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.UserType = userType;
            this.Password = password;
            this.Email = email;
            this.TelephoneNumber = telephoneNumber;
            this.CampusID = campusID;
            this.RoleID = roleID;
            this.StartDate = startDate;
            this.EndDate = endDate;
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public int UserType
        {
            get { return userType; }
            set { userType = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }

        public string TelephoneNumber
        {
            get { return telephoneNumber; }
            set { telephoneNumber = value; }
        }

        public int CampusID
        {
            get { return campusID; }
            set { campusID = value; }
        }

        public int RoleID
        {
            get { return roleID; }
            set { roleID = value; }
        }

        public string StartDate
        {
            get { return startDate; }
            set { startDate = value; }
        }

        public string EndDate
        {
            get { return endDate; }
            set { endDate = value; }
        }
    }
}
