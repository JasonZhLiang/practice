﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Objects
{
    public class Student
    {
        private string firstname;
        private string lastname;
        private int userType;
        private string password;
        private string email;
        private int studentID;
        private string telephoneNumber;
        private int classInfoID;

        public Student()
        {

        }


        public Student(string firstname, string lastname, int userType, string password, string email, int studentID, string telephoneNumber, int classInfoID)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.UserType = userType;
            this.Password = password;
            this.Email = email;
            this.StudentID = studentID;
            this.TelephoneNumber = telephoneNumber;
            this.ClassInfoID = classInfoID;
        }

        public string FirstName
        {
            get { return firstname; }
            set { firstname = value; }
        }
        public string LastName
        {
            get { return lastname; }
            set { lastname = value; }
        }

        public int UserType
        {
            get { return userType; }
            set { userType = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public int StudentID
        {
            get { return studentID; }
            set { studentID = value; }
        }

        public int ClassInfoID
        {
            get { return classInfoID; }
            set { classInfoID = value; }
        }

        public string TelephoneNumber
        {
            get { return telephoneNumber; }
            set { telephoneNumber = value; }
        }

       
    }
}
