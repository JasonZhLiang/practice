﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BusinessLogic
{
    //this layer is just pass up the method calls to the GUI layer

    public class AdministratorBAL
    {
        //create global variable to access the methods of the data layer 
        //for ease of use in other methods
        AdministratorDAL adminDA = new AdministratorDAL();

        public int updateAccount(int id, string email, string fname, string lname, string password, int status)
        {
            try
            {
                return adminDA.UpdateAccount(id, email, fname, lname, password, status);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to populate grid view with all the users and user info
        /// </summary>
        /// <returns></returns>
        public DataTable getAllAccounts()
        {
            try
            {
                return adminDA.GetUserAccounts();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to check for pre-existing records in DB
        /// to help prevent duplicate record insertion
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public int CheckForFaculty(string email)
        {
            try
            {
                return adminDA.CheckForFaculty(email);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to insert faculty to database
        /// using parameters passed from GUI layer
        /// </summary>
        /// <param name="fname"></param>
        /// <param name="lname"></param>
        /// <param name="userType"></param>
        /// <param name="password"></param>
        /// <param name="email"></param>
        /// <param name="telephoneNum"></param>
        /// <param name="campusID"></param>
        /// <param name="roleID"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public int AddFaculty(string fname, string lname, int userType, string password, string email, string telephoneNum, int campusID, int roleID, string startDate, string endDate)
        {
            try
            {
                //call the method from the data layer to insert faculty into database
                return adminDA.AddFacultyToDB(fname, lname, userType, password, email, telephoneNum, campusID, roleID, startDate, endDate);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to insert company to database
        /// using parameters passed from GUI layer
        /// </summary>
        /// <param name="phoneNum"></param>
        /// <param name="compName"></param>
        /// <param name="streetAdd"></param>
        /// <param name="city"></param>
        /// <param name="postal"></param>
        /// <param name="province"></param>
        /// <returns></returns>
        public int AddCompany(string phoneNum, string compName, string streetAdd, string city, string postal, string province)
        {
            try
            {
                //call the method from the data layer to insert company into database
                return adminDA.AddCompanyToDataBase(phoneNum, compName, streetAdd, city, postal, province);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to insert student to database
        /// using parameters passed from GUI layer
        /// </summary>
        /// <param name="first"></param>
        /// <param name="last"></param>
        /// <param name="uType"></param>
        /// <param name="password"></param>
        /// <param name="email"></param>
        /// <param name="studentID"></param>
        /// <param name="phoneNum"></param>
        /// <param name="classID"></param>
        /// <param name="profile"></param>
        /// <returns></returns>
        public int AddStudent(string first, string last, int uType, string password, string email, int studentID, string phoneNum, int classID, string profile)
        {
            try
            {
                return adminDA.AddStudentUser(first,last,uType,password,email,studentID, phoneNum,classID, profile);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to data layer check for existing company data
        /// and aid in preventing duplicate company records
        /// </summary>
        /// <param name="companyName"></param>
        /// <returns></returns>
        public int CheckForCompany(string companyName)
        {
            try
            {
                return adminDA.CheckForCompany(companyName);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to data layer check for existing student data
        /// and aid in preventing duplicate student records
        /// </summary>
        /// <param name="stuID"></param>
        /// <returns></returns>
        public int CheckForStudent(int stuID)
        {
            try
            {
                return adminDA.CheckForStudent(stuID);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to data layer to check for existing company contact data
        /// and aid in preventing duplicate company contact records
        /// </summary>
        /// <param name="email"></param>
        /// <param name="companyID"></param>
        /// <returns></returns>
        public int CheckForCompanyContact(string email, int companyID)
        {
            try
            {
                return adminDA.CheckForCompanyContact(email, companyID);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// method call to data layer to insert company contacts/employers
        /// into the database using parameters passed from the GUI layer
        /// </summary>
        /// <param name="fname"></param>
        /// <param name="lname"></param>
        /// <param name="userType"></param>
        /// <param name="password"></param>
        /// <param name="email"></param>
        /// <param name="companyID"></param>
        /// <param name="telephoneNum"></param>
        /// <param name="department"></param>
        /// <returns></returns>
        public int AddCompanyContact(string fname, string lname, int userType, string password, string email, int companyID, string telephoneNum, string department)
        {
            try
            {
                return adminDA.AddCompanyContact(fname, lname, userType, password, email, companyID, telephoneNum, department);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void populateList(DropDownList list, string StoredProc, string text, string val, string stockMessage)
        {
            try
            {
               adminDA.populateDropDownList(list, StoredProc, text, val, stockMessage);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
