﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BusinessLogic
{
    public class NavbarBAL
    {
        //create global variable to access the methods of the data layer 
        //for ease of use in other methods
        NavbarDAL navbarBA = new NavbarDAL();

        public int CheckUserType(string email)
        {
            try
            {
                return navbarBA.UserTypeCheck(email);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }
}
