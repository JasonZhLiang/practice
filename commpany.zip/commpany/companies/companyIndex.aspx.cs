﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using TripCweb;
public partial class companies_companyIndex : System.Web.UI.Page
{
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {

        MyIFrame.Attributes["src"] = "/companies/postingview.aspx?empty=yes";
        //bool confirmlogin =string.IsNullOrEmpty(Session["email"].ToString());
        if(Session["email"]!=null)
        {
            int usertype = UserTypeCheck(Session["email"].ToString());
            if (usertype != 4)
            {
                Response.Write("<script>alert('Please Login as Company');</script>");
                Response.Redirect("/Account/Login.aspx");
            }
        }
        else
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            //Response.Write("<script>alert('Please Login to a Company account');</script>");
            //Response.Redirect("/Account/Login.aspx");
        }
        
        if (!IsPostBack)
        {
           // Response.Write("<script>alert('Hello welcome to company management Page');</script>");
        }

    }

    public int UserTypeCheck(string email)
    {

        using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
        {
            try
            {
                string strSQL = "checkUserType";
                conn.Open();
                using (SqlCommand compCmd = new SqlCommand(strSQL, conn))
                {
                    compCmd.CommandType = System.Data.CommandType.StoredProcedure;
                    compCmd.Parameters.AddWithValue("@email", email);
                    return (int)compCmd.ExecuteScalar();
                }

            }
            catch (Exception ex)
            {
                FailureText.Text += ex;
                ErrorMessage.Visible = true;
                return -99;
            }
            finally
            {
                conn.Close();
            }
        }
     
    }


    protected void btn_Upload_Click(object sender, EventArgs e)
    {
        if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
        {
            ErrorMessage.Visible = true;
            FailureText.Text = "<br />Error - unable to upload file. Please try again.<br />";
        }
        else
        {
            using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
            {
                try
                {
                    const string SQL = "INSERT INTO [uploadfile] ([MIME], [FileName], [size], [DateTimeUploaded], [BinaryData]) VALUES (@MIME, @FileName, @size, @DateTimeUploaded, @BinaryData)";
                    SqlCommand cmd = new SqlCommand(SQL, Conn);
                    cmd.Parameters.AddWithValue("@MIME", FileToUpload.PostedFile.ContentType);
                    cmd.Parameters.AddWithValue("@FileName", FileName.Text.Trim());
                    cmd.Parameters.AddWithValue("@size", FileToUpload.PostedFile.ContentLength);
                    cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
                    byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                    FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
                    cmd.Parameters.AddWithValue("@BinaryData", imageBytes);


                    Conn.Open();
                    SuccessText.Text = "<br />connection successfully opened <br />";
                    cmd.ExecuteNonQuery();
                    SuccessText.Text += "<br />File successfully uploaded - thank you.<br />";
                    Conn.Close();
                    SuccessText.Text = "well done!";
                    SuccessMessage.Visible = true;
                }
                catch (Exception ex)
                {
                    //FailureText.Text += ex.Message.ToString();
                    FailureText.Text += ex;
                    ErrorMessage.Visible = true;
                    Conn.Close();
                }
            }
        }
    }
    protected void View(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            //int id = int.Parse((sender as LinkButton).CommandArgument);
            int id = 1;
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileCS.ashx?ID="), id);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void btnSubmit_Click(object sender, EventArgs e)
    {

    }

    protected void load1(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/postingForm.aspx";
    }


    protected void btnToStepOne_OnClick(object sender, EventArgs e)
    {
        //mpeOrder2.Hide();
        //mpeOrder.Show();
    }

    protected void btnToStepThree_OnClick(object sender, EventArgs e)
    {
        //mpeOrder2.Hide();
        //mpeOrder3.Show();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/postingForm.aspx?empty=yes";
    }
    protected void Profile_Click(object sender, EventArgs e)
    {

    }
    protected void Posting_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/postingview.aspx?empty=yes";
    }
    protected void Message_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/message.aspx?empty=yes";
    }
    protected void EmailI_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/message.aspx?empty=yes";
    }
    protected void EmailS_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/message.aspx?empty=yes";
    }
    protected void EditPosting_Click(object sender, EventArgs e)
    {
        MyIFrame.Attributes["src"] = "/companies/postingForm.aspx?empty=yes";
    }
    protected void Create_Click(object sender, EventArgs e)
    {

    }
    protected void Edit_Click(object sender, EventArgs e)
    {

    }
    protected void Policy_Click(object sender, EventArgs e)
    {

    }
    protected void Support_Click(object sender, EventArgs e)
    {

    }
}