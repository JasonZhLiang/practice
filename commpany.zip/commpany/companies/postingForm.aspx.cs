﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class companies_postingForm : System.Web.UI.Page
{
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        //for testing purpose set the session id
        Session["useID"] = 1;        
    }
    protected void Submit(object sender, EventArgs e)
    {
        if (IsValid)
        {
            if (chkUpload.Checked)
            {
                if (FileToUpload.PostedFile == null || String.IsNullOrEmpty(FileToUpload.PostedFile.FileName) || FileToUpload.PostedFile.InputStream == null)
                {
                    ErrorMessage.Visible = true;
                    FailureText.Text += "<br />Error - unable to upload file. Please try again.<br />";
                }
                else
                {
                    using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
                    {
                        try
                        {
                            const string SQL = "INSERT INTO [uploadedfile] ([docType], [docName], [docSize], [dateUploaded], [actualFile],[userID]) VALUES (@MIME, @FileName, @Size, @DateTimeUploaded, @BinaryData,@userID)";
                            SqlCommand cmd = new SqlCommand(SQL, Conn);
                            cmd.Parameters.AddWithValue("@MIME", FileToUpload.PostedFile.ContentType);
                            cmd.Parameters.AddWithValue("@FileName", fileName.Text.Trim());
                            cmd.Parameters.AddWithValue("@Size", FileToUpload.PostedFile.ContentLength);
                            cmd.Parameters.AddWithValue("@DateTimeUploaded", DateTime.Now);
                            byte[] imageBytes = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                            FileToUpload.PostedFile.InputStream.Read(imageBytes, 0, imageBytes.Length);
                            cmd.Parameters.AddWithValue("@BinaryData", imageBytes);
                            cmd.Parameters.AddWithValue("@userID", (int)Session["userID"]);

                            Conn.Open();
                            cmd.ExecuteNonQuery();

                            //---------using object-oriented---------------
                            //byte[] imageBytes1 = new byte[FileToUpload.PostedFile.InputStream.Length + 1];
                            //FileToUpload.PostedFile.InputStream.Read(imageBytes1, 0, imageBytes1.Length);

                            //companyDA.jobpostingattachfile(FileToUpload.PostedFile.ContentType,
                            //    fileName.Text.Trim(), FileToUpload.PostedFile.ContentLength
                            //    , DateTime.Now, imageBytes1, (int)Session["userID"]);
                            //----------------------------------------------

                            //get the last insert identity value which is fileID.
                            string sql1 = "SELECT SCOPE_IDENTITY() FROM uploadedfile";// so using two sql command return the ID
                            SqlCommand comm1 = new SqlCommand(sql1, Conn);
                            int fileID = Convert.ToInt32(comm1.ExecuteScalar());

                            //get the companyID value which by userID.
                            string sql2 = "SELECT companyID FROM companycontact WHERE userID=@userID";                               
                            SqlCommand comm2 = new SqlCommand(sql2, Conn);
                            comm2.Parameters.AddWithValue("@userID", Session["userID"]);
                            int companyID = Convert.ToInt32(comm2.ExecuteScalar());

                            string insertPosting = "INSERT INTO [posting] ([companyID],[classInfoID],[title],[description],[duties],[Qualifications],[ContactEmail],[datePosted],[attachedFileID],[dateDue]) VALUES (@companyID,@classInfoID,@title,@description,@duties,@Qualifications,@ContactEmail,@datePosted,@attachedFileID,@dateDue)";
                            SqlCommand comm3 = new SqlCommand(insertPosting, Conn);
                            comm3.Parameters.AddWithValue("@companyID", companyID);
                            comm3.Parameters.AddWithValue("@classInfoID", classinfo.SelectedValue);
                            comm3.Parameters.AddWithValue("@title", jobTitle.Text.Trim());
                            comm3.Parameters.AddWithValue("@description", positionSum.Text);
                            comm3.Parameters.AddWithValue("@duties", duty.Text);
                            comm3.Parameters.AddWithValue("@Qualifications", qualification.Text);
                            comm3.Parameters.AddWithValue("@ContactEmail", email.Text);
                            comm3.Parameters.AddWithValue("@datePosted", startDate.Text);
                            comm3.Parameters.AddWithValue("@attachedFileID", fileID);
                            comm3.Parameters.AddWithValue("@dateDue", dueDate.Text);
                            comm3.Parameters.AddWithValue("@coverletter", chkCover.Checked);
                            int insertPostingint = Convert.ToInt32(comm3.ExecuteNonQuery());
                                
                            Conn.Close();
                            SuccessText.Text = "well done!";
                            SuccessMessage.Visible = true;  
                        }
                        catch (Exception ex)
                        {
                            ErrorMessage.Visible = true;
                            FailureText.Text += ex;
                            Conn.Close();
                        }
                    }
                }
            }

            else
            {
                using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TRIPConnectionString"].ConnectionString))
                {
                    try
                    {
                        //get the companyID value which by userID.
                        string sql2 = "SELECT companyID FROM companycontact WHERE userID=@userID";
                        SqlCommand comm2 = new SqlCommand(sql2, Conn);
                        comm2.Parameters.AddWithValue("@userID", Session["userID"]);
                        Conn.Open();
                        int companyID = Convert.ToInt32(comm2.ExecuteScalar());
                        ;                                                   
                        string insertPosting = "INSERT INTO [posting] ([companyID],[classInfoID],[title],[description],[duties],[Qualifications],[ContactEmail],[datePosted],[attachedFileID],[dateDue],[CoverLetterRequested]) VALUES (@companyID,@classInfoID,@title,@description,@duties,@Qualifications,@ContactEmail,@datePosted,@attachedFileID,@dateDue,@coverletter)";                           
                        SqlCommand comm3 = new SqlCommand(insertPosting, Conn);
                        comm3.Parameters.AddWithValue("@companyID", companyID);
                        comm3.Parameters.AddWithValue("@classInfoID", classinfo.SelectedValue);//using programCode instead
                        comm3.Parameters.AddWithValue("@title", jobTitle.Text.Trim());
                        comm3.Parameters.AddWithValue("@description", positionSum.Text);
                        comm3.Parameters.AddWithValue("@duties", duty.Text);
                        comm3.Parameters.AddWithValue("@Qualifications", qualification.Text);
                        comm3.Parameters.AddWithValue("@ContactEmail", email.Text);
                        comm3.Parameters.AddWithValue("@datePosted", startDate.Text);
                        comm3.Parameters.AddWithValue("@attachedFileID", -999);
                        comm3.Parameters.AddWithValue("@dateDue", dueDate.Text);
                        comm3.Parameters.AddWithValue("@coverletter",chkCover.Checked);
                        Conn.Open();
                        comm3.ExecuteNonQuery();
                        Conn.Close();

                        SuccessText.Text = "well done!";
                        SuccessMessage.Visible = true;
                    }
                    catch (Exception ex)
                    {
                        ErrorMessage.Visible = true;
                        FailureText.Text += ex;
                        Conn.Close();
                    }
                }
            }      
    
        }
        else
        {
            FailureText.Text = "Invalid input.";
            ErrorMessage.Visible = true;
        }
        
        
        

    }
    protected void chkUpload_CheckedChanged(object sender, EventArgs e)
    {
        SuccessMessage.Visible = false; 
        ErrorMessage.Visible = false;
        if (chkUpload.Checked)
        {
            uploadarea.Visible = true;
            fileNameRFV.ValidationGroup = "AllValidators";
            fileRFV.ValidationGroup = "AllValidators";
        }
        else
        {
            uploadarea.Visible = false;
            fileNameRFV.ValidationGroup = "";
            fileRFV.ValidationGroup = "";
        }
    }
}