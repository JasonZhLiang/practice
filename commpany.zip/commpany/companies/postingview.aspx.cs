﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;

public partial class companies_postingview : System.Web.UI.Page
{
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string userID = (string)Session["userID"];
            BindGrid();
            //Response.Write("<script>alert('Hello "+userID+" TRIP test for review pdf from database binary table');</script>");
        }
    }

    //Below is the code which populates the ASP.Net GridView from files saved in the database table.
    private void BindGrid()
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select ID, name, email, password, activated from Users2";
                    cmd.Connection = con;
                    con.Open();
                    GridView1.DataSource = cmd.ExecuteReader();
                    GridView1.DataBind();
                    con.Close();
                    //Response.Write("<script>alert('test test');</script>");
                    //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
                }
            }                    
        
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }

    //The below event handler is raised when the View LinkButton is clicked inside the GridView Row. 
    protected void View(object sender, EventArgs e)
    {
        try
        {  
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileCS.ashx?ID="), id);
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    //remember to change back to view from view1 on Contact.aspx if you want to use above View
    //The below event handler is raised when the View LinkButton is clicked inside the GridView Row. 
    protected void View1(object sender, EventArgs e)
    {
        int id = int.Parse((sender as LinkButton).CommandArgument);
        //String connStr = "connection string";
        string connStr = ConfigurationManager.ConnectionStrings["ConnectionStringUploadFile"].ConnectionString;

        // add here extension that depends on your file type, you can change to any type.
        string fileName = Path.GetTempFileName() + ".doc";
        //string fileName = Path.GetTempFileName() +".pdf";
        try
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    // you have to distinguish here which document, I assume that there is an `id` column
                    //cmd.CommandText = "select document from documents where id = @id";
                    //cmd.Parameters.Add("@id", SqlDbType.Int).Value = 1;

                    cmd.CommandText = "SELECT BinaryData FROM uploadfile WHERE ID = @ID";
                    cmd.Parameters.AddWithValue("@ID", id);

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            int size = 1024 * 1024;
                            byte[] buffer = new byte[size];
                            int readBytes = 0;
                            int index = 0;
                            using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.None))
                            {
                                while ((readBytes = (int)dr.GetBytes(0, index, buffer, 0, size)) > 0)
                                {
                                    fs.Write(buffer, 0, readBytes);
                                    index += readBytes;
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        } 

        // open your file, the proper application will be executed because of proper file extension
        Process prc = new Process();
        prc.StartInfo.FileName = fileName;
        prc.Start();
    }



    protected void butSubmit_Click1(object sender, EventArgs e)
    {
        int id1 = Convert.ToInt32(TextBox1.Text);
        Image2.ImageUrl = "DisplayImg1.ashx?id=" + id1;
    }



    protected void editPosting(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        BindGrid();
    }
    protected void deletePosting(object sender, GridViewDeleteEventArgs e)
    {
        ErrorMessage.Visible = true;
        FailureText.Text += "You are deleting this post...";

    }

    protected void canclePosting(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        BindGrid();
    }
    protected void updatePosting(object sender, GridViewUpdateEventArgs e)
    {
        //int userID = Int32.Parse(GridView1.DataKeys[e.RowIndex].Value.ToString());
        GridViewRow row = GridView1.Rows[e.RowIndex];


        string column1Value = ((TextBox)(row.Cells[3].Controls[0])).Text;
        //string column1Value = ((TextBox)row.Cells[0].Controls[0]).Text;
        
        string column2Value = ((TextBox)(row.Cells[4].Controls[0])).Text;
        string column3Value = ((TextBox)(row.Cells[5].Controls[0])).Text;
        string column4Value = ((TextBox)(row.Cells[6].Controls[0])).Text;
        bool column5Value = ((CheckBox)(row.Cells[7].Controls[0])).Checked;

        using (SqlConnection Conn = new SqlConnection(ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString))
        {
            try
            {

                FailureText.Text += "c1 value" + column1Value + " c2 value" + column2Value + "c5" + column5Value;
                int userID = Int32.Parse(column1Value);
                //bool and the aunto increm int have some 
                string updateuser = "Update Users2 SET email= @email, password = @password WHERE name = @name";
                SqlCommand comm3 = new SqlCommand(updateuser, Conn);
                comm3.Parameters.AddWithValue("@name", column2Value);
                comm3.Parameters.AddWithValue("@email", column3Value);
                comm3.Parameters.AddWithValue("@password", column4Value);
                comm3.Parameters.AddWithValue("@activated", column5Value);
                comm3.Parameters.AddWithValue("@ID", userID);
                Conn.Open();
                comm3.ExecuteNonQuery();
                Conn.Close();
                
                SuccessText.Text = "well done!";
                SuccessMessage.Visible = true;
            }
            catch (Exception ex)
            {
                ErrorMessage.Visible = true;
                FailureText.Text += ex;
                Conn.Close();
            }
        }


        GridView1.EditIndex = -1;
        BindGrid();
    }


    protected void viewresume(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileR.ashx?ID="), id);
            btnClose.Visible = true;
        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    protected void viewcoverletter(object sender, EventArgs e)
    {
        try
        {
            //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
            int id = int.Parse((sender as LinkButton).CommandArgument);
            string embed = "<object data=\"{0}{1}\" type=\"application/pdf\" width=\"800px\" height=\"800px\">";
            embed += "If you are unable to view file, you can download from <a href = \"{0}{1}&download=1\">here</a>";
            embed += " or download <a target = \"_blank\" href = \"http://get.adobe.com/reader/\">Adobe PDF Reader</a> to view the file.";
            embed += "</object>";
            ltEmbed.Text = string.Format(embed, ResolveUrl("FileC.ashx?ID="), id);
            btnClose.Visible = true;

        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }
    }

    protected void viewApplicants(object sender, EventArgs e)
    {
        BindGrid2();
    }
    private void BindGrid2()
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select * from uploadfile";
                    cmd.Connection = con;
                    con.Open();
                    GridView2.DataSource = cmd.ExecuteReader();
                    GridView2.DataBind();
                    con.Close();
                    //Response.Write("<script>alert('test test');</script>");
                    //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
                }
            }

        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }

    protected void btnClose_Click(object sender, EventArgs e)
    {
        ltEmbed.Text = "";
        btnClose.Visible = false;
    }
}