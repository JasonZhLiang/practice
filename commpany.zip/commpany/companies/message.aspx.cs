﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Collections;


public partial class companies_message : System.Web.UI.Page
{
    protected void Page_PreInit(Object sender, EventArgs e)
    {
        this.MasterPageFile = "~/Site.master";
        if (Request.QueryString["empty"] == "yes")
        {
            this.MasterPageFile = "~/Empty.master";
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string userID = (string)Session["userID"];
 
            //Response.Write("<script>alert('Hello "+userID+" TRIP test for review pdf from database binary table');</script>");
        }
    }
    protected void Submit(object sender, EventArgs e)
    {
        //ArrayList selectedemail = new ArrayList();
        //foreach (ListItem name in ListInstructor.Items)
        //{
        //    string li = ListInstructor.SelectedItem.Value;
        //    selectedemail.Add(li);
        //}
        //foreach (ListItem name in ListStudent.Items)
        //{
        //    string li = ListStudent.SelectedItem.Value;
        //    selectedemail.Add(li);
        //}

        //foreach (ListItem item in ListInstructor.Items)
        //{
        //    if (item.Selected)
        //    {
        //        string li = ListInstructor.SelectedItem.Value;
        //        selectedemail.Add(li);
        //    }
        //}

        MailMessage messege = new MailMessage();
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        messege.From = new MailAddress("nbcc.trip@gmail.com");
        foreach (ListItem item in ListInstructor.Items)
        {
            if (item.Selected)
            {
                messege.To.Add(item.Value);
                messege.Subject = subject.Text;
                messege.Body = "Hi " + item.Value + ",<br />" + message.Text;
                messege.IsBodyHtml = true;
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
                client.Send(messege);
            }
        }

        foreach (ListItem item in ListStudent.Items)
        {
            if (item.Selected)
            {
                messege.To.Add(item.Value);
                messege.Subject = subject.Text;
                messege.Body = "Hi " + item.Value + ", <br />" + message.Text;
                messege.IsBodyHtml = true;
                client.EnableSsl = true;
                client.UseDefaultCredentials = true;
                client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
                client.Send(messege);
            }
        } 

        //sendEmail(selectedemail, subject.Text, message.Text);

        SuccessText.Text = "well done!";
        SuccessMessage.Visible = true; 
    }
    protected void chkInstructor_CheckedChanged(object sender, EventArgs e)
    {
        if (chkInstructor.Checked)
        {
            BindGrid();
        }
        else
        {
            ListInstructor.Items.Clear();
        }        
    }
    protected void chkStudent_CheckedChanged(object sender, EventArgs e)
    {
        if (chkStudent.Checked)
        {
            BindGrid1();
        }
        else
        {
            ListStudent.Items.Clear();
        } 
    }

    private void BindGrid()
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select ID, name, email, password, activated from Users2";
                    cmd.Connection = con;
                    con.Open();
                    //ListInstructor.DataSource = cmd.ExecuteReader();
                    //ListInstructor.DataBind();
                    SqlDataReader rd = cmd.ExecuteReader();
                    ListInstructor.SelectionMode = ListSelectionMode.Multiple;
                    while (rd.Read())
                    {
                        ListItem item = new ListItem();
                        item.Text = rd["name"].ToString();
                        item.Value = rd["email"].ToString();
                        ListInstructor.Items.Add(item);
                    }
                    con.Close();
                    //Response.Write("<script>alert('test test');</script>");
                    //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
                }
            }

        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }

    private void BindGrid1()
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["TRIPConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select fName, lName, email from genuser WHERE userType = 2";
                    cmd.Connection = con;
                    con.Open();
                    //ListStudent.DataSource = cmd.ExecuteReader();
                    //ListStudent.DataBind();
                    SqlDataReader rd = cmd.ExecuteReader();
                    ListStudent.SelectionMode = ListSelectionMode.Multiple;
                    while (rd.Read())
                    {
                        ListItem item = new ListItem();
                        item.Text = rd["fName"].ToString()+" "+rd["lName"].ToString();
                        item.Value = rd["email"].ToString();
                        ListStudent.Items.Add(item);
                    }
                    con.Close();
                    //Response.Write("<script>alert('test test');</script>");
                    //ClientScript.RegisterStartupScript(this.GetType(), "catchAlert", "alert('test" + " to test');", true);
                }
            }

        }
        catch (Exception ex)
        {
            ErrorMessage.Visible = true;
            FailureText.Text += ex;
        }

    }


    public void sendEmail(ArrayList emailaddress, string subject, string body)
    {
        MailMessage messege = new MailMessage();
        SmtpClient client = new SmtpClient();
        client.Host = "smtp.gmail.com";
        client.Port = 587;
        messege.From = new MailAddress("nbcc.trip@gmail.com");
        foreach (string a in emailaddress)
        {
            messege.To.Add(a);
            messege.Subject = subject;
            messege.Body = "Hi " + a + ",<br />" + body;
            messege.IsBodyHtml = true;
            client.EnableSsl = true;
            client.UseDefaultCredentials = true;
            client.Credentials = new System.Net.NetworkCredential("nbcc.trip@gmail.com", "nbcctrip");
            client.Send(messege);
        }               
    }
}